from pathlib import Path
import argparse
import ast
import json
import re

import pandas as pd
import yaml

from context_evidence import (build_evidence, eks_public_endpoint_decision,
                              inline_egress_decision, s3_kms_control_decision,
                              s3_public_access_decision,
                              source_inventory, subnet_internet_route, vpc_flow_log_decision)


# ==========================================================
# PATHS
# ==========================================================

DEFAULT_INPUT = Path(
    "results/context_feature_pilot/"
    "pilot_findings.csv"
)

DEFAULT_OUTPUT = Path(
    "results/context_feature_pilot/"
    "finding_context_features_pilot.csv"
)

CORPUS_ROOT = Path(
    "dataset/main/corpus/"
    "geniac_tier_a"
)

SCHEMA = Path(
    "dataset/main/context/"
    "context_schema.yaml"
)

APPLICABILITY = Path(
    "dataset/main/context/"
    "rule_context_applicability.csv"
)

IAM_ACTION_TAXONOMY = Path(
    "dataset/main/context/"
    "iam_action_capability_taxonomy.yaml"
)

RESOURCE_ROLE_TAXONOMY = Path(
    "dataset/main/context/"
    "resource_role_taxonomy.yaml"
)


FEATURES = [
    "internet_exposure",
    "reachability",
    "privilege_impact",
    "resource_role",
    "public_access",
    "wildcard_action",
    "wildcard_resource",
    "encryption_missing",
    "logging_missing",
]


# ==========================================================
# GENERIC HELPERS
# ==========================================================

def as_bool(value):
    if pd.api.types.is_bool_dtype(type(value)):
        return bool(value)

    if isinstance(value, str):
        token = value.strip().lower()
        if token in {"true", "false"}:
            return token == "true"

    raise ValueError(
        f"Invalid applicability Boolean value: {value!r}; "
        "expected True or False"
    )


def parse_int(value, default=1):
    try:
        return int(float(value))
    except Exception:
        return default


def load_evaluated_keys(value):

    if isinstance(value, list):
        return value

    if value is None:
        return []

    text = str(value).strip()

    if not text:
        return []

    try:
        x = json.loads(text)

        if isinstance(x, list):
            return x

        if isinstance(x, str):
            text = x

    except Exception:
        pass

    if re.fullmatch(r"[A-Za-z0-9_./:\[\]-]+", text):
        return [text]

    return []


def statement_index_from_evaluated_keys(
    value,
):

    keys = load_evaluated_keys(value)

    indexes = set()

    for key in keys:

        if not isinstance(key, str):
            continue

        m = re.search(
            r"(?:^|/)Statement/\[(\d+)\](?:/|$)",
            key,
        )

        if m:
            indexes.add(int(m.group(1)))

    if len(indexes) == 1:
        return indexes.pop()

    return None


def strip_quoted_strings(text):
    """
    Remove quoted contents before counting braces.

    This prevents ${...} inside Terraform strings from
    corrupting brace-depth tracking.
    """

    return re.sub(
        r'"(?:\\.|[^"\\])*"',
        '""',
        text,
    )


# ==========================================================
# SOURCE HANDLING
# ==========================================================

def get_source_path(candidate_id):

    return (
        CORPUS_ROOT
        / str(candidate_id)
        / "main.tf"
    )


def read_source(path):

    return path.read_text(
        encoding="utf-8",
        errors="replace",
    )


def source_region(
    full_text,
    line_start,
    line_end,
):
    lines = full_text.splitlines()

    start = max(
        1,
        parse_int(
            line_start,
            1,
        ),
    )

    end = parse_int(
        line_end,
        start,
    )

    end = max(
        start,
        min(
            end,
            len(lines),
        ),
    )

    return "\n".join(
        lines[
            start - 1:end
        ]
    )


# ==========================================================
# RESOURCE ROLE
# ==========================================================

def load_resource_role_taxonomy():
    with RESOURCE_ROLE_TAXONOMY.open(encoding="utf-8") as stream:
        config = yaml.safe_load(stream)

    if (
        not isinstance(config, dict)
        or config.get("taxonomy_version") != "d010-v1"
        or config.get("decision") != "D-010"
        or not isinstance(config.get("mappings"), list)
        or not config["mappings"]
    ):
        raise ValueError("Invalid D-010 resource role taxonomy")

    allowed_roles = {
        "identity", "primary_data", "logging", "network", "compute", "other"
    }
    mappings = {}
    for entry in config["mappings"]:
        if not isinstance(entry, dict) or set(entry) != {"resource_type", "role"}:
            raise ValueError(f"Invalid resource role taxonomy entry: {entry!r}")
        resource_type, role = entry["resource_type"], entry["role"]
        if (
            not isinstance(resource_type, str)
            or re.fullmatch(r"aws_[a-z0-9_]+", resource_type) is None
            or role not in allowed_roles
            or resource_type in mappings
        ):
            raise ValueError(f"Invalid resource role taxonomy mapping: {entry!r}")
        mappings[resource_type] = role

    return config["taxonomy_version"], mappings


RESOURCE_ROLE_TAXONOMY_VERSION, RESOURCE_ROLE_MAP = (
    load_resource_role_taxonomy()
)


def infer_resource_role(resource_type):
    if not isinstance(resource_type, str) or not resource_type.strip():
        raise ValueError("Missing or unreadable resource_type")

    resource_type = resource_type.strip()
    if resource_type not in RESOURCE_ROLE_MAP:
        raise ValueError(
            f"Unmapped resource_type: {resource_type!r} "
            f"in {RESOURCE_ROLE_TAXONOMY} ({RESOURCE_ROLE_TAXONOMY_VERSION})"
        )
    return RESOURCE_ROLE_MAP[resource_type]


# ==========================================================
# IAM PARSING
# ==========================================================

def extract_statement_blocks(
    text,
):
    """
    Extract object blocks inside:

        Statement = [
          { ... },
          { ... }
        ]

    The parser is deliberately narrow and deterministic.
    It is not intended to be a full HCL parser.
    """

    lines = text.splitlines()

    found_statement = False

    blocks = []

    current = []
    depth = 0

    for line in lines:

        clean = strip_quoted_strings(
            line
        )

        if not found_statement:

            match = re.search(
                r"\bStatement\s*=\s*\[",
                clean,
            )

            if not match:
                continue

            found_statement = True
            line = line[match.end():]
            clean = clean[match.end():]

        if not current:

            if re.match(
                r"^\s*\]",
                clean,
            ):
                break

            if "{" in clean:

                current = [line]

                depth = (
                    clean.count("{")
                    - clean.count("}")
                )

                if depth == 0:

                    blocks.append(
                        "\n".join(
                            current
                        )
                    )

                    current = []

            continue

        current.append(
            line
        )

        depth += (
            clean.count("{")
            - clean.count("}")
        )

        if depth == 0:

            blocks.append(
                "\n".join(
                    current
                )
            )

            current = []

    return blocks


def validate_supported_iam_parse(source_text, evaluated_keys):
    """Do not encode a supported-syntax parser failure as research unknown."""
    if statement_index_from_evaluated_keys(evaluated_keys) is None:
        return
    if re.search(r"\bStatement\s*=\s*\[\s*\{", source_text) and not extract_statement_blocks(source_text):
        raise ValueError("Supported IAM Statement syntax could not be parsed")


def extract_assignment(
    text,
    key,
):
    """
    Extract quoted string values assigned to an HCL key.

    Supports:

        Action = "x"

        Action = [
          "x",
          "y",
        ]

    Returns:
        present
        quoted_values
        raw_assignment
    """

    lines = text.splitlines()

    values = []
    raw_parts = []

    present = False

    i = 0

    pattern = re.compile(
        rf"^\s*{re.escape(key)}\s*=\s*(.*)$"
    )

    while i < len(lines):

        line = lines[i]

        m = pattern.match(
            line
        )

        if not m:
            i += 1
            continue

        present = True

        rhs = m.group(1)

        block = [
            rhs
        ]

        clean_rhs = strip_quoted_strings(
            rhs
        )

        bracket_depth = (
            clean_rhs.count("[")
            - clean_rhs.count("]")
        )

        while (
            bracket_depth > 0
            and i + 1 < len(lines)
        ):

            i += 1

            next_line = lines[i]

            block.append(
                next_line
            )

            clean_next = (
                strip_quoted_strings(
                    next_line
                )
            )

            bracket_depth += (
                clean_next.count("[")
                - clean_next.count("]")
            )

        raw = "\n".join(
            block
        )

        raw_parts.append(
            raw
        )

        values.extend(
            re.findall(
                r'"((?:\\.|[^"\\])*)"',
                raw,
            )
        )

        i += 1

    return (
        present,
        values,
        "\n".join(
            raw_parts
        ),
    )


def contains_wildcard(
    values,
):
    return any(
        "*" in str(value)
        for value in values
    )


def load_iam_action_taxonomy():
    with IAM_ACTION_TAXONOMY.open(encoding="utf-8") as stream:
        config = yaml.safe_load(stream)

    if (
        config.get("taxonomy_version") != "d008-v1"
        or config.get("decision") != "D-008"
        or config.get("matching") != "exact_case_insensitive"
    ):
        raise ValueError("Unexpected IAM Action taxonomy version")

    levels = {
        "read_observation": 1,
        "operational_mutation": 2,
        "privilege_administration_or_unrestricted": 3,
    }
    actions = {}
    for capability_class, level in levels.items():
        entries = config.get(capability_class)
        if not isinstance(entries, list):
            raise ValueError(f"Missing IAM Action class: {capability_class}")
        for action in entries:
            if not isinstance(action, str) or not action.strip():
                raise ValueError(f"Invalid IAM Action in {capability_class}")
            key = action.casefold()
            if key in actions:
                raise ValueError(f"Duplicate IAM Action: {action}")
            actions[key] = (capability_class, level)

    unclassified = config.get("unclassified_observed", [])
    if not isinstance(unclassified, list):
        raise ValueError("Invalid unclassified IAM Action list")
    observed = set()
    for action in unclassified:
        if (
            not isinstance(action, str)
            or not action.strip()
            or action.casefold() in actions
            or action.casefold() in observed
        ):
            raise ValueError(f"Conflicting unclassified IAM Action: {action}")
        observed.add(action.casefold())

    return config["taxonomy_version"], actions


IAM_TAXONOMY_VERSION, IAM_ACTION_LEVELS = load_iam_action_taxonomy()


def parse_literal_action(token):
    token = token.strip()
    if not re.fullmatch(r'"(?:\\.|[^"\\])*"', token):
        return None
    try:
        value = json.loads(token)
    except json.JSONDecodeError:
        return None
    if not value or "${" in value or "%{" in value:
        return None
    return value


def resolved_iam_actions(action_raw):
    """Accept literal Action strings/lists; retain uncertainty in a list."""
    raw = action_raw.strip()
    literal = parse_literal_action(raw)
    if literal is not None:
        return [literal], False

    if not (raw.startswith("[") and raw.endswith("]")):
        return [], True

    items = raw[1:-1].split(",")
    actions = []
    unresolved = False
    for index, item in enumerate(items):
        if not item.strip() and index == len(items) - 1:
            continue  # HCL permits a trailing comma.
        literal = parse_literal_action(item)
        if literal is None:
            unresolved = True
        else:
            actions.append(literal)
    return actions, unresolved or not actions


def resolved_iam_effect(effect_raw):
    effect = parse_literal_action(effect_raw)
    return effect if effect in {"Allow", "Deny"} else None


def extract_condition_raw(statement):
    lines = statement.splitlines()
    for index, line in enumerate(lines):
        match = re.match(r"^\s*Condition\s*=\s*(.*)$", line)
        if not match:
            continue
        block = [match.group(1)]
        clean = strip_quoted_strings(block[0])
        depth = clean.count("{") - clean.count("}")
        while depth > 0 and index + 1 < len(lines):
            index += 1
            block.append(lines[index])
            clean = strip_quoted_strings(lines[index])
            depth += clean.count("{") - clean.count("}")
        return "\n".join(block)
    return ""


def classify_privilege_impact(actions, action_unresolved, effect):
    classifications = []
    for action in actions:
        capability_class, level = IAM_ACTION_LEVELS.get(
            action.casefold(), ("unclassified", None)
        )
        classifications.append({
            "action": action,
            "class": capability_class,
            "level": level,
        })

    if effect == "Deny":
        return "0", classifications
    if effect != "Allow":
        return "unknown", classifications

    levels = [item["level"] for item in classifications]
    if 3 in levels:
        return "3", classifications
    if action_unresolved or not levels or None in levels:
        return "unknown", classifications
    return str(max(levels)), classifications


def analyze_iam_statement(
    source_text,
    evaluated_keys,
):

    statement_index = (
        statement_index_from_evaluated_keys(
            evaluated_keys
        )
    )

    blocks = extract_statement_blocks(
        source_text
    )

    selected = ""

    statement_resolution = (
        "unresolved"
    )

    if (
        statement_index is not None
        and statement_index
        < len(blocks)
    ):

        selected = blocks[
            statement_index
        ]

        statement_resolution = (
            f"statement_{statement_index}"
        )

    (
        action_present,
        actions,
        action_raw,
    ) = extract_assignment(
        selected,
        "Action",
    )

    (
        effect_present,
        _,
        effect_raw,
    ) = extract_assignment(
        selected,
        "Effect",
    )
    effect = resolved_iam_effect(effect_raw) if effect_present else None
    resolved_actions, action_unresolved = resolved_iam_actions(action_raw)
    condition_raw = extract_condition_raw(selected)

    (
        resource_present,
        resources,
        resource_raw,
    ) = extract_assignment(
        selected,
        "Resource",
    )

    if not action_present:
        wildcard_action = "unknown"

    elif not resolved_actions:
        wildcard_action = "unknown"

    elif contains_wildcard(resolved_actions):
        wildcard_action = "yes"

    elif action_unresolved:
        wildcard_action = "unknown"

    else:
        wildcard_action = "no"

    # A quoted substring inside an unresolved HCL expression is not
    # evidence that the final Resource value is scoped or wildcard.
    unquoted_resource = re.sub(
        r'"(?:\\.|[^"\\])*"',
        '',
        resource_raw,
    )
    resource_is_literal = (
        resource_present
        and bool(resources)
        and not any(
            '${' in value or '%{' in value
            for value in resources
        )
        and re.fullmatch(r'[\[\],\s]*', unquoted_resource) is not None
    )
    if resource_is_literal:
        wildcard_resource = (
            "yes"
            if contains_wildcard(resources)
            else "no"
        )
    else:
        try:
            resource_expression = ast.parse(
                resource_raw, mode="eval"
            ).body
        except (SyntaxError, ValueError):
            resource_expression = None

        # A direct literal item proves a wildcard even if another
        # item in the same list remains unresolved.
        direct_wildcard = (
            isinstance(resource_expression, ast.List)
            and any(
                isinstance(item, ast.Constant)
                and isinstance(item.value, str)
                and "*" in item.value
                and "${" not in item.value
                and "%{" not in item.value
                for item in resource_expression.elts
            )
        )
        wildcard_resource = "yes" if direct_wildcard else "unknown"

    privilege_impact, action_capabilities = (
        classify_privilege_impact(
            resolved_actions,
            action_unresolved,
            effect,
        )
    )

    evidence = {
        "statement_index": (
            statement_index
        ),
        "statement_resolution": (
            statement_resolution
        ),
        "statement_source": selected,
        "actions": actions,
        "resources": resources,
        "action_assignment_present": (
            action_present
        ),
        "resource_assignment_present": (
            resource_present
        ),
        "action_raw": action_raw,
        "resource_raw": resource_raw,
        "effect": effect,
        "effect_raw": effect_raw,
        "condition_raw": condition_raw,
        "resolved_actions": resolved_actions,
        "action_unresolved": action_unresolved,
        "action_capabilities": action_capabilities,
        "iam_action_taxonomy_version": IAM_TAXONOMY_VERSION,
    }

    return {
        "wildcard_action": (
            wildcard_action
        ),
        "wildcard_resource": (
            wildcard_resource
        ),
        "privilege_impact": (
            privilege_impact
        ),
        "evidence": evidence,
    }


# ==========================================================
# FEATURE EXTRACTION
# ==========================================================

def initialize_features(
    applicability,
    resource_type,
):

    features = {}

    for feature in FEATURES:

        applicable = as_bool(
            applicability[
                feature
            ]
        )

        features[
            feature
        ] = (
            "unknown"
            if applicable
            else "not_applicable"
        )

    # Resource role is deterministic whenever applicable.
    if as_bool(
        applicability[
            "resource_role"
        ]
    ):
        features[
            "resource_role"
        ] = infer_resource_role(
            resource_type
        )

    return features


def extract_features(
    row,
    applicability,
    source_text,
    source_path=None,
):

    check_id = str(
        row["check_id"]
    )

    features = (
        initialize_features(
            applicability,
            row.get("resource_type"),
        )
    )

    evidence = {
        "check_id": check_id,
        "resource": str(
            row["resource"]
        ),
    }

    if as_bool(applicability["resource_role"]):
        resource_type = row["resource_type"].strip()
        role = features["resource_role"]
        evidence["resource_role"] = {
            "resource_type": row["resource_type"],
            "resource_role": role,
            "taxonomy_version": RESOURCE_ROLE_TAXONOMY_VERSION,
            "mapping_entry": {"resource_type": resource_type, "role": role},
        }


    # ======================================================
    # DETECTION / OBSERVABILITY
    # ======================================================

    if check_id == "CKV2_AWS_11":
        if source_path is None:
            raise ValueError("CKV2_AWS_11 candidate source path required")
        decision, details, _ = vpc_flow_log_decision(row, source_path)
        features["logging_missing"] = decision
        evidence["logging"] = details


    # ======================================================
    # S3 PUBLIC ACCESS BLOCK
    # ======================================================

    elif check_id == "CKV2_AWS_6":
        if source_path is None:
            raise ValueError("D-012 S3 candidate source path required")
        bucket_name = str(row["resource"]).split(".", 1)[-1]
        value, details, _ = s3_public_access_decision(
            source_inventory(source_path), bucket_name)
        features["public_access"] = value
        evidence["public_access"] = details


    # ======================================================
    # LAMBDA VPC
    # ======================================================

    elif check_id == "CKV_AWS_117":

        evidence[
            "workload_isolation"
        ] = (
            "Lambda is not configured inside a VPC. "
            "No direct Internet-exposure inference "
            "is made from this fact alone."
        )


    # ======================================================
    # SUBNET AUTO PUBLIC IP
    # ======================================================

    elif check_id == "CKV_AWS_130":

        features[
            "internet_exposure"
        ] = "unknown"

        features[
            "reachability"
        ] = "unknown"

        features[
            "public_access"
        ] = "unknown"

        evidence[
            "network"
        ] = (
            "Subnet assigns public IP by default, "
            "but direct Internet reachability also "
            "depends on routing/IGW evidence."
        )


    # ======================================================
    # S3 KMS
    # ======================================================

    elif check_id == "CKV_AWS_145":
        if source_path is None:
            raise ValueError("S3 KMS control requires affected-bucket source path")
        decision, kms_facts, _ = s3_kms_control_decision(row, source_path)
        features["encryption_missing"] = decision

        evidence[
            "encryption"
        ] = {"control": "KMS-based S3 default encryption",
             "affected_bucket": kms_facts["affected_bucket"],
             "static_decision": decision}


    # ======================================================
    # PUBLIC HTTP INGRESS
    # ======================================================

    elif check_id == "CKV_AWS_260":

        features[
            "internet_exposure"
        ] = "yes"

        features[
            "reachability"
        ] = "internet"

        features[
            "public_access"
        ] = "yes"

        evidence[
            "network"
        ] = {
            "direction": "ingress",
            "source": "0.0.0.0/0",
            "port": 80,
        }


    # ======================================================
    # EKS PUBLIC ENDPOINT
    # ======================================================

    elif check_id == "CKV_AWS_38":
        if source_path is None:
            raise ValueError("CKV_AWS_38 affected EKS source path required")
        decisions, endpoint_facts, _ = eks_public_endpoint_decision(row, source_path)
        features.update(decisions)
        evidence["network"] = {
            "direction": "ingress", "surface": "EKS public endpoint",
            "endpoint_attribute_state": endpoint_facts["endpoint_attribute_state"],
            "public_access_cidrs": endpoint_facts["public_access_cidrs_resolved"],
        }


    # ======================================================
    # UNRESTRICTED EGRESS
    # ======================================================

    elif check_id == "CKV_AWS_382":

        # The finding proves an Internet-facing outbound
        # reachability relationship, not inbound exposure.
        features[
            "internet_exposure"
        ] = "unknown"

        if row["resource_type"] == "aws_security_group":
            if source_path is None:
                raise ValueError("Inline egress requires finding source path")
            reachability, egress_facts, _ = inline_egress_decision(row, source_path)
            features["reachability"] = reachability
            evidence["network"] = {
                "direction": "egress",
                "destination": egress_facts["destination_cidr"],
                "protocol_scope": egress_facts["protocol_scope"],
                "selected_egress_index": egress_facts["selected_egress_index"],
            }
        else:
            features["reachability"] = "internet"

            evidence[
                "network"
            ] = {
                "direction": "egress",
                "destination": "0.0.0.0/0",
                "protocol_scope": "unrestricted",
                "note": (
                    "Outbound Internet path does not "
                    "prove inbound Internet exposure."
                ),
            }


    # ======================================================
    # IAM
    # ======================================================

    elif check_id in {
        "CKV_AWS_290",
        "CKV_AWS_355",
    }:

        iam = analyze_iam_statement(
            source_text,
            row.get(
                "evaluated_keys",
                "",
            ),
        )

        features[
            "privilege_impact"
        ] = iam[
            "privilege_impact"
        ]

        if as_bool(
            applicability[
                "wildcard_action"
            ]
        ):
            features[
                "wildcard_action"
            ] = iam[
                "wildcard_action"
            ]

        if as_bool(
            applicability[
                "wildcard_resource"
            ]
        ):
            features[
                "wildcard_resource"
            ] = iam[
                "wildcard_resource"
            ]

        evidence[
            "iam"
        ] = iam[
            "evidence"
        ]


    else:

        evidence[
            "note"
        ] = (
            "No rule-specific extraction "
            "logic configured."
        )


    return (
        features,
        evidence,
    )


# ==========================================================
# SCHEMA VALIDATION
# ==========================================================

def load_allowed_values():

    with SCHEMA.open(
        encoding="utf-8",
    ) as f:

        schema = yaml.safe_load(
            f
        )

    finding_context = (
        schema[
            "finding_context"
        ]
    )

    allowed = {}

    for feature in FEATURES:

        allowed[
            feature
        ] = {
            str(v)
            for v in (
                finding_context[
                    feature
                ]["values"]
            )
        }

    return allowed


def validate_feature_values(
    features,
    allowed,
):

    errors = []

    for feature in FEATURES:

        value = str(
            features[
                feature
            ]
        )

        if value not in (
            allowed[
                feature
            ]
        ):

            errors.append(
                f"{feature}={value}"
            )

    return errors


# ==========================================================
# MAIN
# ==========================================================


def enforce_applicability(
    features,
    applicability_row,
):
    """
    Final semantic guardrail.

    Any feature marked False in the rule-context applicability
    matrix MUST be represented as 'not_applicable'.

    This function is intentionally executed after rule-specific
    extraction logic so that a rule handler cannot accidentally
    overwrite a non-applicable feature with 'unknown', 'yes',
    'no', or another value.
    """

    feature_names = [
        "internet_exposure",
        "reachability",
        "privilege_impact",
        "resource_role",
        "public_access",
        "wildcard_action",
        "wildcard_resource",
        "encryption_missing",
        "logging_missing",
    ]

    for feature in feature_names:

        if feature not in applicability_row:
            raise KeyError(
                f"Applicability matrix missing feature: "
                f"{feature}"
            )

        if not as_bool(
            applicability_row[feature]
        ):
            features[feature] = (
                "not_applicable"
            )

    return features


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--input",
        default=str(
            DEFAULT_INPUT
        ),
    )

    parser.add_argument(
        "--output",
        default=str(
            DEFAULT_OUTPUT
        ),
    )

    args = parser.parse_args()

    input_path = Path(
        args.input
    )

    output_path = Path(
        args.output
    )


    df = pd.read_csv(
        input_path
    ).fillna("")


    applicability_df = (
        pd.read_csv(
            APPLICABILITY
        )
        .fillna("")
    )


    applicability_map = {
        str(row["check_id"]): row
        for _, row
        in applicability_df.iterrows()
    }

    for check_id, applicability in applicability_map.items():
        for feature in FEATURES:
            try:
                applicability[feature] = as_bool(
                    applicability[feature]
                )
            except ValueError as exc:
                raise ValueError(
                    f"{APPLICABILITY}: check_id={check_id}, "
                    f"feature={feature}: {exc}"
                ) from exc

    allowed_values = (
        load_allowed_values()
    )


    rows = []


    for _, row in df.iterrows():

        check_id = str(
            row["check_id"]
        )

        candidate_id = str(
            row["candidate_id"]
        )

        source_path = (
            get_source_path(
                candidate_id
            )
        )


        if check_id not in (
            applicability_map
        ):

            raise ValueError(
                "Missing applicability row "
                f"for {check_id}"
            )


        applicability = (
            applicability_map[
                check_id
            ]
        )


        if not source_path.exists():
            raise ValueError(f"Required Terraform source missing: {source_path}")
        else:

            full_source = (
                read_source(
                    source_path
                )
            )

            source_text = (
                source_region(
                    full_source,
                    row.get(
                        "line_start",
                        1,
                    ),
                    row.get(
                        "line_end",
                        1,
                    ),
                )
            )

            source_status = "OK"

        if check_id in {"CKV_AWS_290", "CKV_AWS_355"}:
            validate_supported_iam_parse(
                source_text, row.get("evaluated_keys", ""))

        (
            features,
            evidence,
        ) = extract_features(
            row,
            applicability,
            source_text,
            source_path,
        )

        if check_id == "CKV_AWS_130":
            route_proven, _, _ = subnet_internet_route(row, source_inventory(source_path))
            if route_proven:
                features["reachability"] = "internet"


        # ==================================================
        # FINAL APPLICABILITY ENFORCEMENT
        # ==================================================
        #
        # The applicability matrix is the final authority.
        # Any feature marked False must become
        # "not_applicable" before validation, unknown
        # counting, and output generation.
        #
        features = enforce_applicability(
            features,
            applicability,
        )


        validation_errors = (
            validate_feature_values(
                features,
                allowed_values,
            )
        )


        if validation_errors:

            extraction_status = (
                "SCHEMA_VALUE_ERROR"
            )

        elif source_status != "OK":

            extraction_status = (
                source_status
            )

        else:

            extraction_status = (
                "EXTRACTED"
            )


        applicable_unknowns = []

        for feature in FEATURES:

            if (
                as_bool(
                    applicability[
                        feature
                    ]
                )
                and str(
                    features[
                        feature
                    ]
                ) == "unknown"
            ):
                applicable_unknowns.append(
                    feature
                )


        out = {
            "finding_id": (
                row["finding_id"]
            ),
            "candidate_id": (
                candidate_id
            ),
            "scenario_id": (
                row["scenario_id"]
            ),
            "check_id": (
                check_id
            ),
            "check_name": (
                row.get(
                    "check_name",
                    "",
                )
            ),
            "resource": (
                row["resource"]
            ),
            "resource_type": (
                row["resource_type"]
            ),
            "source_path": str(
                source_path
            ),
            "line_start": (
                row.get(
                    "line_start",
                    "",
                )
            ),
            "line_end": (
                row.get(
                    "line_end",
                    "",
                )
            ),
            "evaluated_keys": (
                row.get(
                    "evaluated_keys",
                    "",
                )
            ),
        }


        out.update(
            features
        )


        out.update({
            "feature_extraction_status": (
                extraction_status
            ),
            "schema_validation_errors": (
                "|".join(
                    validation_errors
                )
            ),
            "applicable_unknown_count": (
                len(
                    applicable_unknowns
                )
            ),
            "applicable_unknown_features": (
                "|".join(
                    applicable_unknowns
                )
            ),
            "feature_evidence": (
                json.dumps(
                    build_evidence(row, features, applicability, evidence,
                                   source_path, APPLICABILITY),
                    ensure_ascii=False,
                    sort_keys=True,
                )
            ),
        })


        rows.append(
            out
        )


    result = pd.DataFrame(
        rows
    )


    output_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )


    result.to_csv(
        output_path,
        index=False,
    )


    print("==============================")
    print("PILOT CONTEXT FEATURE EXTRACTION")
    print("==============================")

    print(
        "Input rows =",
        len(df),
    )

    print(
        "Output rows =",
        len(result),
    )

    print(
        "Unique finding IDs =",
        result[
            "finding_id"
        ].nunique(),
    )

    print(
        "Rules =",
        result[
            "check_id"
        ].nunique(),
    )

    print()

    print("=== EXTRACTION STATUS ===")

    print(
        result[
            "feature_extraction_status"
        ]
        .value_counts(
            dropna=False
        )
        .to_string()
    )

    print()

    print("=== UNKNOWN COUNTS ===")

    print(
        result[
            "applicable_unknown_count"
        ]
        .value_counts()
        .sort_index()
        .to_string()
    )

    print()

    print("=== FEATURE DISTRIBUTIONS ===")

    for feature in FEATURES:

        print()
        print(
            f"[{feature}]"
        )

        print(
            result[
                feature
            ]
            .value_counts(
                dropna=False
            )
            .to_string()
        )

    print()

    print(
        "Output =",
        output_path,
    )


if __name__ == "__main__":
    main()
