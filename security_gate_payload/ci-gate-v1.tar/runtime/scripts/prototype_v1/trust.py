"""Versioned CI trust adapter for an externally verified D-038 release."""

import hashlib
import json
import io
import os
import stat
from pathlib import Path


REPO = Path(__file__).resolve().parents[2]
MODEL = Path("results/prototype/model_v1/deployment_model_v1.joblib")
METADATA = Path("results/prototype/model_v1/deployment_model_v1_metadata.json")
CHECKSUM = Path("results/prototype/model_v1/deployment_model_v1.sha256")
POLICY = Path("results/main_benchmark/phase8_prototype_policy_v1.json")
ACCEPTANCE = Path("results/prototype/model_v1/deployment_model_v1_acceptance.json")
ACCEPTANCE_CHECKSUM = Path("results/prototype/model_v1/deployment_model_v1_acceptance.sha256")
ANCHORS = {
    MODEL: "5ed8eb2bb44af178a748c1d6902917f5459a4361ba8171a5181960a06c6eb4c1",
    METADATA: "14b0cc27474ace77426e25aaa73daa83302a31558503a39246689e7f7219b70c",
    CHECKSUM: "3bc26fb62422cea2e9b79a42dc3c3e3597f18055d92f82cc71bf534d52f6cbcb",
    POLICY: "735bff1ed574c93f9fe320ac27dd07aadbd06988c2c281346efab0b6262cdec5",
    ACCEPTANCE: "1d01104da52a7874de4c8d097e97ff602cb5520eb8d40237dbe0b960bd1a7d57",
    ACCEPTANCE_CHECKSUM: "aa60e012676545abd350bd11684fc27f1a46ebcd8898db4ec6a1fe8aab1dcb58",
}


class ModelTrustError(ValueError):
    """The accepted local deployment package cannot be trusted."""


def _read_snapshot(root: Path, rel: Path) -> bytes:
    """Read once through no-follow descriptors; later pathname swaps are irrelevant."""
    if rel.is_absolute() or not rel.parts or any(x in {"..", "."} for x in rel.parts):
        raise ModelTrustError("Invalid trusted relative path")
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    fd = os.open(root, flags)
    try:
        for part in rel.parts[:-1]:
            next_fd = os.open(part, flags, dir_fd=fd)
            os.close(fd)
            fd = next_fd
        file_fd = os.open(rel.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
        with os.fdopen(file_fd, "rb") as stream:
            if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
                raise ModelTrustError(f"Nonregular trusted file: {rel}")
            return stream.read()
    finally:
        os.close(fd)


def _verified_snapshots(root: Path, anchors: dict[Path, str]) -> dict:
    snapshots = {}
    try:
        for rel, expected in anchors.items():
            raw = _read_snapshot(root, rel)
            if hashlib.sha256(raw).hexdigest() != expected:
                raise ModelTrustError(f"Frozen SHA-256 mismatch: {rel}")
            snapshots[rel] = raw
    except OSError as exc:
        raise ModelTrustError(f"Untrusted package path: {exc}") from exc
    return snapshots


def _verify_bundle(root: Path, anchors: dict[Path, str]) -> tuple[dict, dict]:
    """Testable gate; all interpretation is bound to the verified byte snapshots."""
    return _validate_bundle(_verified_snapshots(root, anchors), anchors)


def _validate_bundle(snapshots: dict, anchors: dict) -> tuple[dict, dict]:
    record = snapshots[CHECKSUM].decode("utf-8")
    expected_record = f"{anchors[MODEL]}  {MODEL}\n{anchors[METADATA]}  {METADATA}\n"
    if record != expected_record:
        raise ModelTrustError("Deployment checksum record mismatch")
    acceptance_record = snapshots[ACCEPTANCE_CHECKSUM].decode("utf-8")
    if acceptance_record != f"{anchors[ACCEPTANCE]}  {ACCEPTANCE}\n":
        raise ModelTrustError("Deployment acceptance checksum mismatch")
    try:
        metadata = json.loads(snapshots[METADATA])
        policy = json.loads(snapshots[POLICY])
        acceptance = json.loads(snapshots[ACCEPTANCE])
    except (ValueError, UnicodeError) as exc:
        raise ModelTrustError("Invalid accepted package metadata") from exc
    if metadata.get("model_sha256") != anchors[MODEL]:
        raise ModelTrustError("Model hash metadata mismatch")
    if metadata.get("policy") != {"path": str(POLICY), "policy_id": "phase8-prototype-policy-v1", "sha256": anchors[POLICY]}:
        raise ModelTrustError("Active policy metadata mismatch")
    if metadata.get("deployment_model_id") != "rf_severity_context_deployment_v1" or metadata.get("scientific_model_identity") != "rf_severity_context_v1" or metadata.get("deployment_model_scientifically_evaluated") is not False:
        raise ModelTrustError("Model identity/scientific boundary mismatch")
    if policy.get("deployment_model", {}).get("deployment_model_id") != metadata["deployment_model_id"]:
        raise ModelTrustError("Policy/model identity mismatch")
    if metadata.get("predictors") != policy.get("deployment_training", {}).get("predictors"):
        raise ModelTrustError("Predictor contract mismatch")
    if metadata.get("category_domains") != policy.get("deployment_training", {}).get("category_domains"):
        raise ModelTrustError("Category contract mismatch")
    if metadata.get("random_forest_parameters") != policy.get("deployment_training", {}).get("random_forest_parameters"):
        raise ModelTrustError("RF contract mismatch")
    if metadata.get("target", {}).get("name") != "priority_target_norm" or metadata.get("target", {}).get("source_sha256") != policy.get("frozen_source_sha256", {}).get(metadata.get("target", {}).get("source_path")):
        raise ModelTrustError("Target provenance mismatch")
    if metadata.get("preprocessing", {}).get("categorical_encoder", {}).get("categories") != metadata.get("category_domains"):
        raise ModelTrustError("Preprocessing provenance mismatch")
    if acceptance.get("status") != "accepted":
        raise ModelTrustError("D-038 acceptance missing")
    return metadata, policy


def load_accepted_model():
    """Return the accepted pipeline only after all fixed-path gates pass."""
    try:
        from .ci_release_verifier import RECEIPT, VERSION, digest, parse_object, verify

        mode = os.environ.get("CI_GATE_DEV_ONLY")
        if mode not in {"0", "1"}:
            raise ModelTrustError("Use the trusted CI release launcher")
        release = verify(REPO.parent, os.environ.get("CI_GATE_MANIFEST_SHA256"),
                         dev_only=mode == "1", allow_venv=True)
        snapshots = {rel: release["runtime/" + rel.as_posix()] for rel in ANCHORS}
        if any(digest(snapshots[rel]) != expected for rel, expected in ANCHORS.items()):
            raise ModelTrustError("Frozen deployment anchor mismatch")
        metadata, policy = _validate_bundle(snapshots, ANCHORS)
        pin_digest = digest(json.dumps(policy["frozen_source_sha256"], sort_keys=True,
                                      separators=(",", ":")).encode("utf-8"))
        receipt = parse_object(release[RECEIPT])
        if (receipt.get("release_id") != VERSION or receipt.get("research_verification") != "PASS"
                or receipt.get("verified_research_pin_count") != 61
                or receipt.get("research_pin_set_sha256") != pin_digest
                or receipt.get("model_sha256") != ANCHORS[MODEL]
                or receipt.get("operational_policy_sha256") != ANCHORS[POLICY]):
            raise ModelTrustError("CI build provenance mismatch")
        from . import ci_runtime_contract as trainer
        expected = {
            "deployment_model_id": trainer.DEPLOYMENT_MODEL_ID,
            "scientific_model_identity": trainer.SCIENTIFIC_MODEL_ID,
            "purpose": "operational_prototype",
            "scientific_evaluation_source": "D-030 OOF Random Forest result",
            "deployment_model_scientifically_evaluated": False,
            "training_population_rows": 300,
            "predictors": list(trainer.PREDICTORS),
            "category_domains": trainer.CATEGORIES,
            "random_forest_parameters": trainer.RF_PARAMS,
            "runtime_versions": trainer.runtime_versions(),
            "model_path": str(MODEL), "model_sha256": ANCHORS[MODEL],
            "policy_id": trainer.POLICY_ID, "policy_sha256": ANCHORS[POLICY],
            "policy": {"path": str(POLICY), "policy_id": trainer.POLICY_ID, "sha256": ANCHORS[POLICY]},
            "target": trainer.target_metadata(policy),
            "preprocessing": trainer.preprocessing_metadata(),
            "training_benchmark_path": str(trainer.BENCHMARK_PATH),
            "training_benchmark_sha256": policy["frozen_source_sha256"][str(trainer.BENCHMARK_PATH)],
            "target_artifact": {"path": str(trainer.TARGET_PATH), "sha256": policy["frozen_source_sha256"][str(trainer.TARGET_PATH)]},
            "severity_mapping": {"path": str(trainer.SEVERITY_PATH), "sha256": policy["frozen_source_sha256"][str(trainer.SEVERITY_PATH)]},
            "feature_schema": policy["feature_schema"],
        }
        if any(metadata.get(key) != value for key, value in expected.items()):
            raise ModelTrustError("Deployment metadata/runtime contract mismatch")
        import joblib
        pipeline = joblib.load(io.BytesIO(snapshots[MODEL]))
        from sklearn.compose import ColumnTransformer
        from sklearn.ensemble import RandomForestRegressor
        from sklearn.pipeline import Pipeline
        if (not isinstance(pipeline, Pipeline) or len(pipeline.steps) != 2
                or not isinstance(pipeline.steps[0][1], ColumnTransformer)
                or not isinstance(pipeline.steps[1][1], RandomForestRegressor)
                or list(pipeline.feature_names_in_) != metadata["predictors"]):
            raise ModelTrustError("Serialized deployment pipeline structure mismatch")
        preprocessor, estimator = pipeline.steps[0][1], pipeline.steps[1][1]
        encoder, columns = preprocessor.transformers_[0][1:]
        if (list(columns) != list(trainer.CONTEXT_FIELDS)
                or [list(x) for x in encoder.categories_] != [trainer.CATEGORIES[x] for x in trainer.CONTEXT_FIELDS]
                or encoder.drop is not None or encoder.handle_unknown != "error"
                or encoder.sparse_output is not False or preprocessor.remainder != "drop"
                or list(preprocessor.transformers_[1][2]) != ["severity_numeric"]
                or any(estimator.get_params()[key] != value for key, value in trainer.RF_PARAMS.items())):
            raise ModelTrustError("Serialized preprocessing/RF contract mismatch")
        return pipeline, metadata, policy
    except (OSError, KeyError, TypeError, ValueError) as exc:
        if isinstance(exc, ModelTrustError):
            raise
        raise ModelTrustError(str(exc)) from exc
