"""Strict Checkov normalization and deterministic Phase-8 identities."""

import hashlib
import json
from pathlib import Path, PurePosixPath
import re


SCHEMA_VERSION = "phase8-security-gate-v1"


class ProvenanceError(ValueError):
    pass


class CheckovParseError(ValueError):
    pass


def canonical_json(value) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(value) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()


def safe_tf_files(root: Path) -> list[Path]:
    root = root.resolve(strict=True)
    if not root.is_dir():
        raise ProvenanceError("Terraform root is not a directory")
    for p in root.rglob("*"):
        if p.is_symlink():
            raise ProvenanceError(f"Terraform source contains a symlink: {p}")
    files = sorted((p for p in root.rglob("*.tf") if p.is_file()), key=lambda p: p.relative_to(root).as_posix())
    if not files:
        raise ProvenanceError("Terraform root has no .tf files")
    if any(root.rglob("*.tf.json")):
        raise ProvenanceError("Terraform JSON source is outside the frozen extractor")
    return files


def source_manifest(root: Path) -> dict[str, str]:
    return {path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in safe_tf_files(root)}


def assert_source_manifest(root: Path, expected: dict) -> None:
    if source_manifest(root) != expected:
        raise ProvenanceError("Terraform source snapshot changed or was copied incompletely")


def artifact_id(root: Path) -> tuple[str, list[str]]:
    root = root.resolve(strict=True)
    files = safe_tf_files(root)
    h = hashlib.sha256(b"phase8-artifact-v1\0")
    names = []
    for path in files:
        name = path.relative_to(root).as_posix()
        names.append(name)
        for data in (name.encode("utf-8"), path.read_bytes()):
            h.update(len(data).to_bytes(8, "big"))
            h.update(data)
    return h.hexdigest(), names


def context_id(context: dict) -> str:
    return digest({k: context[k] for k in ("environment", "asset_criticality", "data_sensitivity")})


def run_id(artifact: str, context: str, terraform_version: str, checkov_version: str,
           model_id: str, model_sha256: str, feature_policy_version: str) -> str:
    return digest({
        "schema_version": SCHEMA_VERSION, "artifact_id": artifact, "context_id": context,
        "terraform_version": terraform_version, "checkov_version": checkov_version,
        "deployment_model_id": model_id, "deployment_model_sha256": model_sha256,
        "feature_policy_version": feature_policy_version,
    })


def relative_source_path(raw: str, root: Path) -> str:
    """Checkov -d may emit /main.tf; absolute files inside root are also valid."""
    if not isinstance(raw, str) or not raw.strip() or "\\" in raw or "\0" in raw:
        raise ProvenanceError("Invalid Checkov source path")
    root = root.resolve(strict=True)
    candidate = Path(raw)
    if candidate.is_absolute():
        try:
            rel = candidate.relative_to(root)
        except ValueError:
            if candidate.exists():
                raise ProvenanceError("Checkov source points outside Terraform root")
            # Checkov's repo_file_path is slash-prefixed but root-relative.
            rel = Path(raw.lstrip("/"))
    else:
        rel = candidate
    parts = PurePosixPath(rel.as_posix()).parts
    if not parts or any(part in {"..", "."} for part in parts):
        raise ProvenanceError("Checkov source escapes Terraform root")
    path = root.joinpath(*parts)
    if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(root):
        raise ProvenanceError(f"Checkov source missing or redirected: {raw}")
    if path.suffix != ".tf":
        raise ProvenanceError("Checkov source is not a .tf file")
    return path.relative_to(root).as_posix()


def _invalid_json_constant(value):
    raise CheckovParseError(f"Nonstandard scanner JSON constant: {value}")


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise CheckovParseError(f"Duplicate scanner JSON key: {key}")
        result[key] = value
    return result


def _results_documents(raw):
    try:
        data = json.loads(raw, object_pairs_hook=_unique_object, parse_constant=_invalid_json_constant) if isinstance(raw, (str, bytes)) else raw
    except (UnicodeError, ValueError) as exc:
        raise CheckovParseError("Malformed Checkov JSON") from exc
    docs = data if isinstance(data, list) else [data]
    if not docs or any(not isinstance(d, dict) for d in docs):
        raise CheckovParseError("Invalid Checkov JSON document shape")
    return docs


def _resource_type(resource: str) -> str:
    match = re.search(r"(?:^|\.)(aws_[A-Za-z0-9_]+)(?:\.|$)", resource)
    return match.group(1) if match else ""


def _canonical_scanner_evidence(value, root: Path):
    """Keep complete evidence while removing absolute temporary-root spelling."""
    if isinstance(value, dict):
        return {key: _canonical_scanner_evidence(item, root) for key, item in value.items()}
    if isinstance(value, list):
        return [_canonical_scanner_evidence(item, root) for item in value]
    if isinstance(value, str):
        return value.replace(str(root.resolve(strict=True)), "${TERRAFORM_ROOT}")
    return value


def _check_occurrence(item: dict, root: Path):
    """Return a located occurrence; malformed evidence must never skip checks.

    Native Checkov 3.3.17 SKIPPED records can omit evaluated_keys. Preserve
    that absence as an unknown scope, not an invented empty evaluated-key list.
    A cross-collection match with an unknown scope is ambiguous and rejected.
    Distinct explicit evaluated-key scopes retain statement-level identities.
    """
    result = item["check_result"]
    if "evaluated_keys" in result:
        keys = result["evaluated_keys"]
        if not isinstance(keys, list) or any(not isinstance(key, str) for key in keys):
            raise CheckovParseError("Malformed Checkov evaluated_keys: expected a list of strings")
        # Logical scope ignores repeated paths; keep raw keys/evidence untouched.
        scope = tuple(sorted(set(keys)))
    elif result["result"] == "SKIPPED":
        # BaseCheck.run() emits native skips without evaluated keys.
        scope = None
    else:
        raise CheckovParseError("Missing evaluated_keys for a non-skipped Checkov record")
    check_id, resource = item.get("check_id"), item.get("resource")
    source = item.get("repo_file_path") or item.get("file_path")
    lines = item.get("file_line_range")
    if not all(isinstance(x, str) and x.strip() for x in (check_id, resource, source)):
        raise ProvenanceError("Missing critical Checkov occurrence identity")
    if (not isinstance(lines, (list, tuple)) or len(lines) < 2
            or any(type(x) is not int for x in lines[:2])):
        raise ProvenanceError("Missing Checkov occurrence line range")
    rel = relative_source_path(source, root)
    if not 1 <= lines[0] <= lines[1] <= len((root / rel).read_text(encoding="utf-8").splitlines()):
        raise ProvenanceError("Checkov occurrence line range outside source")
    return (check_id, resource, rel, lines[0], lines[1], scope)


def parse_failed_findings(raw, root: Path) -> tuple[list[dict], str | None]:
    findings, reported_versions, occurrences = [], set(), {}
    for doc in _results_documents(raw):
        count_fields = ("passed", "failed", "skipped", "parsing_errors", "resource_count")
        summary_only = "check_type" not in doc and "results" not in doc
        summary = doc if summary_only else doc.get("summary")
        if not isinstance(summary, dict):
            raise CheckovParseError("Missing Checkov summary")
        for field in count_fields:
            if type(summary.get(field)) is not int or summary[field] < 0:
                raise CheckovParseError(f"Invalid or missing Checkov count: {field}")
        if summary.get("checkov_version") != "3.3.17":
            raise CheckovParseError("Unsupported Checkov JSON version")
        reported_versions.add(summary["checkov_version"])
        if summary_only:
            # Observed 3.3.17 empty-scan shape; every relevant count must be zero.
            if any(summary[field] != 0 for field in count_fields):
                raise CheckovParseError("Contradictory Checkov summary-only scan")
            continue
        if doc.get("check_type") != "terraform" or not isinstance(doc.get("results"), dict):
            raise CheckovParseError("Expected Terraform Checkov results")
        results = doc["results"]
        for count, field in (("passed", "passed_checks"), ("failed", "failed_checks"),
                             ("skipped", "skipped_checks"), ("parsing_errors", "parsing_errors")):
            if not isinstance(results.get(field), list) or summary[count] != len(results[field]):
                raise CheckovParseError(f"Checkov summary/list mismatch: {field}")
        if summary["parsing_errors"]:
            raise CheckovParseError("Checkov reported Terraform parsing errors")
        if summary["resource_count"] == 0 and any(summary[x] for x in ("passed", "failed", "skipped")):
            raise CheckovParseError("Checkov reports checks without resources")
        for field, expected in (("passed_checks", "PASSED"), ("failed_checks", "FAILED"),
                                ("skipped_checks", "SKIPPED")):
            for item in results[field]:
                if not isinstance(item, dict):
                    raise CheckovParseError(f"Invalid Checkov record in {field}")
                result = item.get("check_result")
                if (not isinstance(result, dict) or not isinstance(result.get("result"), str)
                        or result["result"] != expected):
                    raise CheckovParseError(f"{field} entry must have result {expected}")
                occurrence = _check_occurrence(item, root)
                base, scope = occurrence[:-1], occurrence[-1]
                previous = occurrences.setdefault(base, set())
                if any(other_field != field and (scope is None or other_scope is None or scope == other_scope)
                       for other_scope, other_field in previous):
                    raise CheckovParseError("Same or ambiguous Checkov occurrence in incompatible collections")
                previous.add((scope, field))
        failed = results["failed_checks"]
        for item in failed:
            if not isinstance(item, dict):
                raise CheckovParseError("Invalid Checkov failed finding")
            check_id, name, resource = (item.get(k) for k in ("check_id", "check_name", "resource"))
            line_range = item.get("file_line_range")
            source_raw = item.get("repo_file_path") or item.get("file_path")
            if not all(isinstance(x, str) and x.strip() for x in (check_id, name, resource, source_raw)):
                raise ProvenanceError("Missing critical Checkov finding identity")
            if not isinstance(line_range, (list, tuple)) or len(line_range) < 2 or any(type(x) is not int for x in line_range[:2]):
                raise ProvenanceError("Missing Checkov finding line range")
            start, end = line_range[:2]
            rel = relative_source_path(source_raw, root)
            if start < 1 or end < start or end > len((root / rel).read_text(encoding="utf-8").splitlines()):
                raise ProvenanceError("Checkov finding line range outside source")
            result = item.get("check_result")
            if not isinstance(result, dict) or result.get("result") != "FAILED":
                raise CheckovParseError("failed_checks entry is not FAILED")
            findings.append({
                "check_id": check_id, "check_name": name, "resource": resource,
                "resource_type": _resource_type(resource), "source_path": rel,
                "line_start": start, "line_end": end,
                "evaluated_keys": result["evaluated_keys"],
                "scanner_evidence": _canonical_scanner_evidence(item, root),
            })
    if len(reported_versions) > 1:
        raise CheckovParseError("Conflicting Checkov versions")
    assign_finding_ids(findings)
    return findings, next(iter(reported_versions), None)


def assign_finding_ids(findings: list[dict]) -> None:
    groups = {}
    for finding in findings:
        key = {
            "check_id": finding["check_id"], "resource_identity": finding["resource"],
            "relative_source_path": finding["source_path"],
            "line_start": finding["line_start"], "line_end": finding["line_end"],
        }
        groups.setdefault(digest(key), []).append((finding, key))
    used = set()
    for base, members in groups.items():
        if len(members) == 1:
            members[0][0]["finding_id"] = base
            used.add(base)
            continue
        evidence_hashes = [digest(f["scanner_evidence"]) for f, _ in members]
        if len(set(evidence_hashes)) != len(evidence_hashes):
            raise ProvenanceError("Indistinguishable duplicate Checkov findings")
        for (finding, key), evidence_hash in zip(members, evidence_hashes):
            unique = digest({**key, "canonical_evidence_occurrence": evidence_hash})
            if unique in used:
                raise ProvenanceError("Checkov finding identity collision")
            finding["finding_id"] = unique
            used.add(unique)
