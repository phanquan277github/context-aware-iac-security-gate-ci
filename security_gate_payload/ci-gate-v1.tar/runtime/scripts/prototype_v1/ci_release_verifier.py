"""Verify a CI Gate bundle against a digest supplied by a trusted caller."""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys


VERSION = "ci-gate-v1"
SCHEMA = "ci-gate-release-manifest-v1"
MANIFEST = "release-manifest.json"
RECEIPT = "build-receipt.json"
DEV_STATUS = "UNSIGNED_DEV_ONLY"
APPROVED_STATUS = "EXTERNALLY_APPROVED"
DIGEST_RE = re.compile(r"[0-9a-f]{64}")


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def relative_parts(value):
    if not isinstance(value, str):
        raise ValueError("Path must be a POSIX relative string")
    parts = value.split("/")
    if not all(re.fullmatch(r"[A-Za-z0-9_.-]+", part) and part not in {".", ".."}
               for part in parts):
        raise ValueError("Unsafe relative path")
    return parts


def directory(path):
    path = Path(os.path.abspath(path))
    if path.resolve(strict=True) != path:
        raise ValueError("Symlink in directory path")
    return path


def read_snapshot(root, relative):
    """Bind interpretation to the same regular file bytes that were checked."""
    parts = relative_parts(relative)
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    fd = os.open(root, flags)
    try:
        for part in parts[:-1]:
            child = os.open(part, flags, dir_fd=fd)
            os.close(fd)
            fd = child
        file_fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                          dir_fd=fd)
        with os.fdopen(file_fd, "rb") as stream:
            info = os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                raise ValueError("Expected a regular file without hardlinks")
            return stream.read()
    finally:
        os.close(fd)


def parse_object(raw):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate JSON key")
            result[key] = value
        return result

    def invalid_constant(_):
        raise ValueError("Non-finite JSON value")

    value = json.loads(raw.decode("utf-8"), object_pairs_hook=unique,
                       parse_constant=invalid_constant)
    if not isinstance(value, dict):
        raise ValueError("Expected a JSON object")
    return value


def _inventory(root, allowed_dirs, allow_venv):
    found = set()

    def visit(path):
        for node in path.iterdir():
            rel = node.relative_to(root).as_posix()
            info = node.lstat()
            if rel == "runtime/.venv" and allow_venv and stat.S_ISDIR(info.st_mode):
                # Operational overlay provisioned separately by the trusted runner.
                continue
            if stat.S_ISDIR(info.st_mode) and rel in allowed_dirs:
                visit(node)
            elif stat.S_ISREG(info.st_mode) and info.st_nlink == 1:
                found.add(rel)
            else:
                raise ValueError("Unexpected directory, link or special file in release")

    visit(root)
    return found


def verify(root, expected_manifest_sha256, *, dev_only=False, allow_venv=False):
    """The digest must originate outside the release. This never imports payload code."""
    root = directory(root)
    if not DIGEST_RE.fullmatch(expected_manifest_sha256 or ""):
        raise ValueError("External manifest SHA-256 is required")
    manifest_raw = read_snapshot(root, MANIFEST)
    if digest(manifest_raw) != expected_manifest_sha256:
        raise ValueError("Release manifest SHA-256 mismatch")
    manifest = parse_object(manifest_raw)
    if (set(manifest) != {"schema_version", "release_id", "authorization", "files"}
            or manifest["schema_version"] != SCHEMA or manifest["release_id"] != VERSION):
        raise ValueError("Unexpected release identity/schema")
    expected_status = DEV_STATUS if dev_only else APPROVED_STATUS
    if manifest["authorization"] != expected_status:
        raise ValueError("Release not authorized for the chosen mode")
    if not isinstance(manifest["files"], list) or not manifest["files"]:
        raise ValueError("Empty release manifest")
    expected = {}
    directories = set()
    seen = {MANIFEST.casefold()}
    for entry in manifest["files"]:
        if not isinstance(entry, dict) or set(entry) != {"path", "size_bytes", "sha256"}:
            raise ValueError("Invalid release manifest entry")
        path, size, sha = entry["path"], entry["size_bytes"], entry["sha256"]
        parts = relative_parts(path)
        if (path.casefold() in seen
                or (path != RECEIPT and (len(parts) < 2 or parts[0] != "runtime"))
                or parts[:2] == ["runtime", ".venv"]
                or type(size) is not int or size < 0
                or not isinstance(sha, str) or not DIGEST_RE.fullmatch(sha)):
            raise ValueError("Invalid release path, size or hash")
        seen.add(path.casefold())
        expected[path] = entry
        directories.update(str(parent) for parent in PurePosixPath(path).parents
                           if str(parent) != ".")
    if (RECEIPT not in expected or not any(p.startswith("runtime/") for p in expected)
            or any(p.casefold() in seen for p in directories)
            or len(directories) != len({p.casefold() for p in directories})):
        raise ValueError("Missing receipt/runtime or conflicting release paths")
    if _inventory(root, directories, allow_venv) != set(expected) | {MANIFEST}:
        raise ValueError("Release inventory differs from manifest")
    snapshots = {}
    for path, entry in expected.items():
        raw = read_snapshot(root, path)
        if len(raw) != entry["size_bytes"] or digest(raw) != entry["sha256"]:
            raise ValueError("Release file size or SHA-256 mismatch: " + path)
        snapshots[path] = raw
    return snapshots


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release", required=True, type=Path)
    parser.add_argument("--expected-manifest-sha256", required=True)
    parser.add_argument("--dev-only", action="store_true")
    parser.add_argument("--launch", action="store_true")
    parser.add_argument("gate_arguments", nargs=argparse.REMAINDER)
    args = parser.parse_args(argv)
    try:
        if args.gate_arguments and not args.launch:
            raise ValueError("Gate arguments require --launch")
        release = directory(args.release)
        verify(release, args.expected_manifest_sha256, dev_only=args.dev_only,
               allow_venv=args.launch)
        if not args.launch:
            print(json.dumps({"release_id": VERSION, "integrity": "PASS",
                              "authorization": DEV_STATUS if args.dev_only else APPROVED_STATUS}))
            return 0
        runtime = release / "runtime"
        executable = runtime / ".venv/bin/python"
        # CI-2 provisions this overlay from an independent, trusted dependency lock.
        if not executable.is_file():
            raise ValueError("Provision the trusted Python environment at runtime/.venv")
        checkov = runtime / ".venv/bin/checkov"
        if not checkov.is_file() or checkov.is_symlink():
            raise ValueError("Trusted Checkov entrypoint missing")
        arguments = args.gate_arguments
        if arguments and arguments[0] == "--":
            arguments = arguments[1:]
        env = {name: os.environ[name] for name in
               ("PATH", "HOME", "LANG", "LC_ALL", "TMPDIR", "TF_CLI_CONFIG_FILE")
               if name in os.environ}
        env.update({"AWS_EC2_METADATA_DISABLED": "true",
                    "AWS_CONFIG_FILE": "/dev/null",
                    "AWS_SHARED_CREDENTIALS_FILE": "/dev/null",
                    "TF_IN_AUTOMATION": "1", "CHECKPOINT_DISABLE": "1",
                    "CI_GATE_MANIFEST_SHA256": args.expected_manifest_sha256,
                    "CI_GATE_DEV_ONLY": "1" if args.dev_only else "0"})
        bootstrap = ("import runpy,sys; sys.path.insert(0,sys.argv.pop(1)); "
                     "runpy.run_module('scripts.run_prototype_gate_v1',run_name='__main__')")
        # The trusted caller must isolate the read-only release from PR writes.
        result = subprocess.run([str(executable), "-I", "-B", "-c", bootstrap,
                                 str(runtime), *arguments], env=env, check=False)
        return result.returncode if result.returncode in {0, 10, 20} else 20
    except (OSError, RuntimeError, TypeError, ValueError) as exc:
        print(f"CI_RELEASE_TRUST_ERROR: {exc}", file=sys.stderr)
        return 20


if __name__ == "__main__":
    raise SystemExit(main())
