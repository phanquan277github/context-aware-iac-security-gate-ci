"""Operational source adapter calling the frozen D-007–D-012 extractor."""

import csv
import hashlib
import importlib
import os
import re

import hcl2
from pathlib import Path
import sys

from .normalization_identity import ProvenanceError, safe_tf_files
from .trust import REPO


FEATURES = (
    "internet_exposure", "reachability", "privilege_impact", "resource_role",
    "public_access", "wildcard_action", "wildcard_resource", "encryption_missing",
    "logging_missing",
)
SUPPORTED_RULES = frozenset({
    "CKV2_AWS_11", "CKV2_AWS_6", "CKV_AWS_117", "CKV_AWS_130",
    "CKV_AWS_145", "CKV_AWS_260", "CKV_AWS_290", "CKV_AWS_355",
    "CKV_AWS_38", "CKV_AWS_382",
})


class FeatureExtractionError(ValueError):
    pass


def _import_frozen_extractor():
    """Import helper definitions only; never call its corpus-processing main()."""
    scripts_dir = str(REPO / "scripts")
    if scripts_dir not in sys.path:
        sys.path.insert(0, scripts_dir)
    previous = Path.cwd()
    try:
        # Its frozen taxonomy loaders use repository-relative paths at import.
        os.chdir(REPO)
        extractor = importlib.import_module("extract_finding_context_features")
        evidence = importlib.import_module("context_evidence")
    finally:
        os.chdir(previous)
    extractor.SCHEMA = REPO / "dataset/main/context/context_schema.yaml"
    extractor.APPLICABILITY = REPO / "dataset/main/context/rule_context_applicability.csv"
    extractor.IAM_ACTION_TAXONOMY = REPO / "dataset/main/context/iam_action_capability_taxonomy.yaml"
    extractor.RESOURCE_ROLE_TAXONOMY = REPO / "dataset/main/context/resource_role_taxonomy.yaml"
    return extractor, evidence


def load_applicability() -> dict[str, dict]:
    path = REPO / "dataset/main/context/rule_context_applicability.csv"
    with path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    result = {}
    for row in rows:
        check_id = row["check_id"]
        if check_id in result:
            raise FeatureExtractionError(f"Duplicate applicability: {check_id}")
        if any(row.get(field) not in {"True", "False"} for field in FEATURES):
            raise FeatureExtractionError(f"Invalid applicability: {check_id}")
        result[check_id] = row
    if set(result) != SUPPORTED_RULES:
        raise FeatureExtractionError("Applicability rule scope differs from frozen allowlist")
    return result


def load_severity() -> tuple[dict[str, int], str]:
    path = REPO / "results/main_benchmark/severity_mapping_v1.csv"
    with path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    result = {}
    versions = set()
    for row in rows:
        check_id = row["check_id"]
        if check_id in result:
            raise FeatureExtractionError(f"Duplicate D-022 severity: {check_id}")
        value = int(row["severity_numeric"])
        if value not in {1, 2, 3, 4}:
            raise FeatureExtractionError(f"Invalid D-022 severity: {check_id}")
        result[check_id] = value
        versions.add(row["mapping_version"])
    if set(result) != SUPPORTED_RULES or len(versions) != 1:
        raise FeatureExtractionError("D-022 severity scope/version mismatch")
    return result, versions.pop()


def _root_inventory(root: Path, source_path: Path) -> list[dict]:
    root = root.resolve(strict=True)
    source_path = source_path.resolve(strict=True)
    if not source_path.is_relative_to(root):
        raise ProvenanceError("Finding source escapes Terraform root")
    all_files = safe_tf_files(root)
    if source_path not in all_files:
        raise ProvenanceError("Finding source absent from Terraform inventory")
    # Terraform module ownership is directory-scoped, not recursive.
    files = [path for path in all_files if path.parent == source_path.parent]
    return [{"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
            for path in files]


def _module_declarations(directory: Path) -> dict:
    declarations = {}
    for path in sorted(directory.glob("*.tf")):
        with path.open(encoding="utf-8") as stream:
            parsed = hcl2.load(stream)
        for entry in parsed.get("module", []):
            for name, body in entry.items():
                if name in declarations:
                    raise FeatureExtractionError("module_scope_unresolved: duplicate module declaration")
                declarations[name] = body
    return declarations


def _resolve_local_finding(finding: dict, root: Path, source_path: Path, evidence_module) -> dict:
    """Verify ownership first; strip module prefixes only in the helper-facing copy."""
    address = finding["resource"]
    scope = root
    while address.startswith("module."):
        match = re.match(r"module\.([A-Za-z0-9_-]+)\.", address)
        if not match:
            raise FeatureExtractionError("module_scope_unresolved: indexed or ambiguous module address")
        name = match.group(1)
        declaration = _module_declarations(scope).get(name)
        local_source = declaration.get("source") if isinstance(declaration, dict) else None
        # Installed python-hcl2 represents attributes as one-element lists.
        if isinstance(local_source, list) and len(local_source) == 1:
            local_source = local_source[0]
        if (not isinstance(local_source, str) or not local_source.startswith(("./", "../"))
                or "${" in local_source or any(k in declaration for k in ("count", "for_each"))):
            raise FeatureExtractionError("module_scope_unresolved: module is not a static local instance")
        scope = (scope / local_source).resolve(strict=True)
        if not scope.is_dir() or not scope.is_relative_to(root):
            raise FeatureExtractionError("module_scope_unresolved: local module escapes snapshot")
        address = address[match.end():]
    if scope != source_path.parent.resolve(strict=True):
        raise FeatureExtractionError("module_scope_unresolved: source does not belong to addressed module")
    match = re.fullmatch(r"(aws_[A-Za-z0-9_]+)\.([A-Za-z0-9_-]+)(\[[^\]]+\])?", address)
    if not match or match.group(1) != finding["resource_type"]:
        raise FeatureExtractionError("module_scope_unresolved: invalid resource address")
    resource_type, name, index = match.groups()
    # Frozen subnet helpers explicitly support count indices. Other indexed
    # identities are not silently rewritten into unindexed helper identities.
    if index and finding["check_id"] != "CKV_AWS_130":
        raise FeatureExtractionError("module_scope_unresolved: resource index outside supported helper scope")
    declarations = [block for block in evidence_module.resource_blocks(_root_inventory(root, source_path), resource_type)
                    if block[0] == name]
    if len(declarations) != 1:
        raise FeatureExtractionError("module_scope_unresolved: resource declaration not unique")
    _, _, block_path, start, end = declarations[0]
    if (Path(block_path) != source_path or finding["line_start"] < start
            or finding["line_end"] > end):
        raise FeatureExtractionError("module_scope_unresolved: finding location does not match resource declaration")
    return {**finding, "resource": address}


def extract_features_for_finding(finding: dict, terraform_root: Path,
                                 applicability: dict, domains: dict) -> tuple[dict, dict]:
    """Reuse frozen rule handlers with verified module-local evidence inventory."""
    extractor, evidence_module = _import_frozen_extractor()
    root = terraform_root.resolve(strict=True)
    source_path = root / finding["source_path"]
    if (not source_path.is_file() or source_path.is_symlink()
            or not source_path.resolve().is_relative_to(root)):
        raise FeatureExtractionError("Required Terraform source unavailable")
    try:
        local_finding = _resolve_local_finding(finding, root, source_path, evidence_module)
        source_text = extractor.source_region(source_path.read_text(encoding="utf-8"),
                                              finding["line_start"], finding["line_end"])
        if finding["check_id"] in {"CKV_AWS_290", "CKV_AWS_355"}:
            extractor.validate_supported_iam_parse(source_text, finding.get("evaluated_keys", []))
        def inventory(path):
            return _root_inventory(terraform_root, Path(path))
        original_evidence = evidence_module.source_inventory
        original_extractor = extractor.source_inventory
        try:
            # Frozen helpers resolve this function at call time; the CLI is
            # single-threaded, and both original references are restored.
            evidence_module.source_inventory = inventory
            extractor.source_inventory = inventory
            features, trace = extractor.extract_features(
                local_finding, applicability, source_text, source_path
            )
            if finding["check_id"] == "CKV_AWS_130":
                route_proven, _, _ = extractor.subnet_internet_route(local_finding, inventory(source_path))
                if route_proven:
                    features["reachability"] = "internet"
        finally:
            evidence_module.source_inventory = original_evidence
            extractor.source_inventory = original_extractor
        features = extractor.enforce_applicability(features, applicability)
        errors = extractor.validate_feature_values(features, extractor.load_allowed_values())
        if errors:
            raise FeatureExtractionError("Frozen feature schema mismatch: " + ", ".join(errors))
        if any(features.get(field) not in domains[field] for field in FEATURES):
            raise FeatureExtractionError("Deployment category domain mismatch")
        return {key: str(features[key]) for key in FEATURES}, trace
    except (OSError, KeyError, TypeError, ValueError) as exc:
        if isinstance(exc, FeatureExtractionError):
            raise
        raise FeatureExtractionError(f"Frozen feature extraction failed: {type(exc).__name__}: {exc}") from exc
