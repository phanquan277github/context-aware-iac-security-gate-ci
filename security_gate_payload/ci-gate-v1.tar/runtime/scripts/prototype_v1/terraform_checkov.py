"""Isolated Terraform validation and complete Checkov Terraform scan."""

from pathlib import Path
import json
import shutil
import os
import stat
import subprocess
import tempfile

from .normalization_identity import CheckovParseError, ProvenanceError, safe_tf_files, source_manifest, assert_source_manifest


class ToolError(RuntimeError):
    def __init__(self, code: str, message: str, details: dict | None = None, stages: dict | None = None):
        super().__init__(message)
        self.code = code
        self.details = details or {}
        self.stages = stages or {}


def _run(argv: list[str], cwd: Path, timeout: int, error_code: str) -> dict:
    try:
        completed = subprocess.run(argv, cwd=cwd, capture_output=True, text=True,
                                   encoding="utf-8", errors="replace", timeout=timeout,
                                   check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ToolError(error_code, f"{type(exc).__name__}: {exc}") from exc
    return {"returncode": completed.returncode, "stdout": completed.stdout,
            "stderr": completed.stderr, "command": argv}


def tool_version(argv: list[str], cwd: Path, error_code: str) -> str:
    result = _run(argv, cwd, 30, error_code)
    if result["returncode"] != 0:
        raise ToolError(error_code, "Tool version query failed", result)
    return result["stdout"].strip()


def terraform_version(root: Path) -> str:
    raw = tool_version(["terraform", "version", "-json"], root, "TERRAFORM_INIT_ERROR")
    try:
        version = json.loads(raw)["terraform_version"]
    except (ValueError, KeyError, TypeError) as exc:
        raise ToolError("TERRAFORM_INIT_ERROR", "Invalid Terraform version output") from exc
    return str(version)


def checkov_binary(repo: Path) -> Path:
    binary = repo / ".venv/bin/checkov"
    if not binary.is_file() or binary.is_symlink():
        raise ToolError("CHECKOV_EXECUTION_ERROR", "Trusted local Checkov executable missing")
    return binary


def checkov_version(repo: Path) -> str:
    return tool_version([str(checkov_binary(repo)), "--version"], repo, "CHECKOV_EXECUTION_ERROR")


def _copy_directory(source_fd: int, destination: Path) -> None:
    """No-follow descriptor traversal, including ancillary local module files."""
    destination.mkdir()
    for name in sorted(os.listdir(source_fd)):
        if name in {".terraform", ".git", ".venv", "__pycache__"}:
            continue
        entry = os.stat(name, dir_fd=source_fd, follow_symlinks=False)
        if stat.S_ISDIR(entry.st_mode):
            fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=source_fd)
            try:
                _copy_directory(fd, destination / name)
            finally:
                os.close(fd)
        elif stat.S_ISREG(entry.st_mode):
            fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=source_fd)
            with os.fdopen(fd, "rb") as src:
                if not stat.S_ISREG(os.fstat(src.fileno()).st_mode):
                    raise ProvenanceError("Nonregular source during copying")
                with (destination / name).open("xb") as dst:
                    shutil.copyfileobj(src, dst)
        else:
            raise ProvenanceError(f"Redirected or special Terraform source: {name}")


def isolated_copy(root: Path):
    source = root.resolve(strict=True)
    intended = source_manifest(source)
    temporary = tempfile.TemporaryDirectory(prefix="phase8-gate-")
    destination = Path(temporary.name) / "terraform"
    try:
        fd = os.open(source, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            _copy_directory(fd, destination)
        finally:
            os.close(fd)
        assert_source_manifest(source, intended)
        assert_source_manifest(destination, intended)
    except Exception:
        temporary.cleanup()
        raise
    return temporary, destination


def validate_terraform(working_root: Path) -> dict:
    stages = {"terraform_init": "not_run", "terraform_validate": "not_run"}
    for stage, command, timeout, code in (
        ("terraform_init", ["terraform", "init", "-backend=false", "-input=false", "-no-color"], 180, "TERRAFORM_INIT_ERROR"),
        ("terraform_validate", ["terraform", "validate", "-no-color"], 120, "TERRAFORM_VALIDATE_ERROR"),
    ):
        try:
            result = _run(command, working_root, timeout, code)
            stages[stage] = {"status": "success" if result["returncode"] == 0 else "error", **result}
            if result["returncode"] != 0:
                raise ToolError(code, f"{stage} failed", result, dict(stages))
        except ToolError as exc:
            if stages[stage] == "not_run":
                stages[stage] = {"status": "error", **exc.details}
            exc.stages = dict(stages)
            raise
    return stages


def scan_checkov(working_root: Path, repo: Path) -> dict:
    binary = checkov_binary(repo)
    result = _run([str(binary), "-d", str(working_root), "--framework", "terraform",
                   "-o", "json", "--soft-fail",
                   "--download-external-modules", "false"],
                  working_root, 300, "CHECKOV_EXECUTION_ERROR")
    if result["returncode"] != 0:
        raise ToolError("CHECKOV_EXECUTION_ERROR", "Checkov process failed", result)
    if not result["stdout"].strip():
        raise ToolError("CHECKOV_JSON_PARSE_ERROR", "Empty Checkov JSON output")
    return result
