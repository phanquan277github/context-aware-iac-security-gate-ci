"""D-038 contract from accepted, hash-verified trainer source."""

from pathlib import Path
import sys

import joblib
import numpy as np
import pandas as pd
import sklearn

BENCHMARK_PATH = Path("results/main_benchmark/benchmark_v1.csv")

TARGET_PATH = Path("results/main_annotation/phase4_derived_targets_v1.csv")

SEVERITY_PATH = Path("results/main_benchmark/severity_mapping_v1.csv")

POLICY_ID = "phase8-prototype-policy-v1"

DEPLOYMENT_MODEL_ID = "rf_severity_context_deployment_v1"

SCIENTIFIC_MODEL_ID = "rf_severity_context_v1"

TARGET = "priority_target_norm"

TARGET_FREEZE_ID = "phase4-derived-targets-v1"

CONTEXT_FIELDS = (
    "environment", "asset_criticality", "data_sensitivity",
    "internet_exposure", "reachability", "privilege_impact",
    "resource_role", "public_access", "wildcard_action",
    "wildcard_resource", "encryption_missing", "logging_missing",
)

PREDICTORS = CONTEXT_FIELDS + ("severity_numeric",)

CATEGORIES = {
    "environment": ["dev", "prod"],
    "asset_criticality": ["low", "high"],
    "data_sensitivity": ["low", "high"],
    "internet_exposure": ["yes", "no", "unknown", "not_applicable"],
    "reachability": ["internal", "internet", "unknown", "not_applicable"],
    "privilege_impact": ["0", "1", "2", "3", "unknown", "not_applicable"],
    "resource_role": ["identity", "primary_data", "logging", "network", "compute", "other"],
    "public_access": ["yes", "no", "unknown", "not_applicable"],
    "wildcard_action": ["yes", "no", "unknown", "not_applicable"],
    "wildcard_resource": ["yes", "no", "unknown", "not_applicable"],
    "encryption_missing": ["yes", "no", "unknown", "not_applicable"],
    "logging_missing": ["yes", "no", "unknown", "not_applicable"],
}

RF_PARAMS = {
    "n_estimators": 300,
    "criterion": "squared_error",
    "max_depth": 6,
    "min_samples_split": 10,
    "min_samples_leaf": 5,
    "max_features": 1.0,
    "bootstrap": True,
    "random_state": 20261006,
    "n_jobs": 1,
}

def runtime_versions():
    return {
        "python": sys.version.split()[0],
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "scikit_learn": sklearn.__version__,
        "joblib": joblib.__version__,
    }

def target_metadata(policy):
    return {
        "name": TARGET,
        "role": "deployment_training_target",
        "source_path": str(TARGET_PATH),
        "source_sha256": policy["frozen_source_sha256"][str(TARGET_PATH)],
        "derivation_freeze_id": TARGET_FREEZE_ID,
    }

def preprocessing_metadata():
    return {
        "type": "ColumnTransformer",
        "categorical_encoder": {
            "type": "OneHotEncoder",
            "categories": CATEGORIES,
            "drop": None,
            "handle_unknown": "error",
            "sparse_output": False,
            "dtype": "float",
        },
        "categorical_predictors": list(CONTEXT_FIELDS),
        "numeric_predictors": ["severity_numeric"],
        "severity_handling": "passthrough",
        "remainder": "drop",
        "fit_scope": "full frozen 300-row deployment-training population",
    }
