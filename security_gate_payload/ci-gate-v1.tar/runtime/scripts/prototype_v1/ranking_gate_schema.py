"""Tie-aware operational ranking, gate states, and policy JSON checks."""

import csv
import hashlib
import io
import math
from pathlib import Path
import re
from datetime import datetime

from .normalization_identity import context_id, run_id
from .trust import ANCHORS, MODEL, METADATA, REPO, _read_snapshot
from .feature_adapter import SUPPORTED_RULES


EXIT_CODES = {"PASS": 0, "REVIEW": 10, "ERROR": 20}
FORBIDDEN_FIELDS = {"human_rank", "relevance_grade", "priority_target_norm"}



SEVERITY_PATH = Path("results/main_benchmark/severity_mapping_v1.csv")
SEVERITY_SHA256 = "6d765ab79b58c11ea1d65eef85f3429d74fef5f7a2ebcec3ff3fcaca160e4b9f"
SEVERITY_VERSION = "phase4-severity-mapping-v1"


def _verified_severity(policy: dict) -> dict[str, int]:
    """Use only pinned D-022 bytes; no caller-supplied editable severity table.

    The descriptor snapshot binds CSV interpretation to the bytes hashed here,
    rather than reopening a pathname after validation. Values come from D-022.
    """
    if (policy.get("frozen_source_sha256", {}).get(str(SEVERITY_PATH)) != SEVERITY_SHA256
            or set(policy.get("supported_rules", [])) != SUPPORTED_RULES):
        raise ValueError("Unverified D-022 severity policy")
    try:
        raw = _read_snapshot(REPO, SEVERITY_PATH)
    except OSError as exc:
        raise ValueError("D-022 severity source unavailable") from exc
    if hashlib.sha256(raw).hexdigest() != SEVERITY_SHA256:
        raise ValueError("Frozen D-022 severity SHA-256 mismatch")
    rows = list(csv.DictReader(io.StringIO(raw.decode("utf-8"))))
    mapping = {row["check_id"]: int(row["severity_numeric"]) for row in rows}
    if (len(rows) != len(mapping) or set(mapping) != SUPPORTED_RULES
            or any(value not in {1, 2, 3, 4} for value in mapping.values())
            or any(row["mapping_version"] != SEVERITY_VERSION for row in rows)):
        raise ValueError("Frozen D-022 severity contract mismatch")
    return mapping


def rank_supported(findings: list[dict]) -> list[dict]:
    scores = [item["priority_score"] for item in findings]
    if any(isinstance(score, bool) or not isinstance(score, (int, float)) or not math.isfinite(score)
           for score in scores):
        raise ValueError("Nonfinite or invalid priority_score")
    for item in findings:
        score = item["priority_score"]
        greater = sum(other > score for other in scores)
        tied = sum(other == score for other in scores)
        item["priority_rank_expected"] = 1 + greater + (tied - 1) / 2
        item["priority_tie_group_size"] = tied
    return sorted(findings, key=lambda item: (-item["priority_score"], item["finding_id"]))


def gate_status(failed_findings_total: int, complete: bool = True) -> str:
    if not complete:
        return "ERROR"
    if failed_findings_total < 0:
        raise ValueError("Invalid failed finding count")
    return "REVIEW" if failed_findings_total else "PASS"


def validate_output(document: dict, policy: dict) -> None:
    schema = policy["json_schema"]
    if document.get("schema_version") != schema["schema_version"]:
        raise ValueError("JSON schema version mismatch")
    for field in schema["top_level"]:
        if field not in document:
            raise ValueError(f"Missing JSON top-level field: {field}")
    for group in ("input", "business_context", "tool_versions", "model_provenance", "execution_status", "counts"):
        obj = document[group]
        if not isinstance(obj, dict) or any(name not in obj for name in schema[group]):
            raise ValueError(f"Incomplete JSON {group}")
    for field in ("ranked_supported_findings", "unsupported_findings", "warnings", "errors"):
        if not isinstance(document[field], list):
            raise ValueError(f"JSON {field} must be a list")
    gate = document["gate_status"]
    if gate not in EXIT_CODES or type(document.get("exit_code")) is not int or document["exit_code"] != EXIT_CODES[gate]:
        raise ValueError("Gate/exit code mismatch")
    stages = document["execution_status"]
    stage_states = []
    for name in schema["execution_status"]:
        entry = stages[name]
        state = entry.get("status") if isinstance(entry, dict) else entry
        if state not in {"not_run", "success", "error"}:
            raise ValueError("Invalid execution stage status")
        if isinstance(entry, dict) and "returncode" in entry:
            code = entry["returncode"]
            if type(code) is not int or (state == "success" and code != 0):
                raise ValueError("Stage status contradicts tool exit")
        stage_states.append(state)
    # These five stages execute in order; later success cannot bypass an earlier failure.
    for index, state in enumerate(stage_states):
        if state == "success" and any(x != "success" for x in stage_states[:index]):
            raise ValueError("Execution stage order contradiction")
    if gate != "ERROR" and (any(x != "success" for x in stage_states) or document["errors"]):
        raise ValueError("Completed gate requires completed stages and no errors")
    if gate == "ERROR" and not document["errors"]:
        raise ValueError("ERROR requires explicit error provenance")
    counts = document["counts"]
    if any(type(counts[name]) is not int or counts[name] < 0 for name in schema["counts"]):
        raise ValueError("Counts must be nonnegative integers")
    supported, unsupported = document["ranked_supported_findings"], document["unsupported_findings"]
    domains = policy["deployment_training"]["category_domains"]
    ids = set()
    def finite_number(value):
        return type(value) in (int, float) and math.isfinite(value)
    def hash_value(value):
        return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None
    for item in supported + unsupported:
        if not isinstance(item, dict) or not hash_value(item.get("finding_id")) or item["finding_id"] in ids:
            raise ValueError("Invalid or duplicate finding identity")
        ids.add(item["finding_id"])
        if (any(not isinstance(item.get(name), str) or not item[name] for name in
                ("check_id", "check_name", "resource", "source_path"))
                or item["source_path"] not in document["input"]["terraform_files"]
                or type(item.get("line_start")) is not int or type(item.get("line_end")) is not int
                or not 1 <= item["line_start"] <= item["line_end"]):
            raise ValueError("Invalid finding location/provenance")
    severity = _verified_severity(policy) if supported else {}
    scores = [item.get("priority_score") for item in supported]
    for item in supported:
        if any(name not in item for name in schema["supported_finding"]):
            raise ValueError("Incomplete supported finding")
        features = item.get("context_features")
        if (item.get("unsupported_for_ml") is not False or not isinstance(features, dict)
                or set(features) != set(domains) or any(features[key] not in values for key, values in domains.items())):
            raise ValueError("Invalid contextual feature vector")
        if (item["check_id"] not in severity
                or type(item["severity_numeric"]) is not int
                or item["severity_numeric"] != severity[item["check_id"]]
                or item["severity_mapping_version"] != SEVERITY_VERSION):
            raise ValueError("Invalid supported rule/severity provenance")
        if not finite_number(item["priority_score"]):
            raise ValueError("Supported score must be finite")
        score = item["priority_score"]
        if any(not finite_number(x) for x in scores):
            raise ValueError("Supported score must be finite")
        tied = sum(other == score for other in scores)
        expected = 1 + sum(other > score for other in scores) + (tied - 1) / 2
        if (type(item["priority_tie_group_size"]) is not int or item["priority_tie_group_size"] != tied
                or not finite_number(item["priority_rank_expected"]) or item["priority_rank_expected"] != expected):
            raise ValueError("Tie-aware ranking metadata mismatch")
    reason_allowlist = {"UNSUPPORTED_RULE", "UNSCORABLE_FEATURE_EXTRACTION"}
    for item in unsupported:
        if any(name not in item for name in schema["unsupported_finding"]):
            raise ValueError("Incomplete unsupported finding")
        if (item.get("unsupported_for_ml") is not True or item.get("unsupported_reason") not in reason_allowlist
                or any(item.get(field) is not None for field in ("priority_score", "priority_rank_expected", "priority_tie_group_size"))):
            raise ValueError("Invalid unsupported finding")
        in_scope = item["check_id"] in policy["supported_rules"]
        if in_scope != (item["unsupported_reason"] == "UNSCORABLE_FEATURE_EXTRACTION"):
            raise ValueError("Unsupported reason contradicts rule scope")
    if (counts["failed_findings_total"] != len(supported) + len(unsupported)
            or counts["supported_findings"] != len(supported)
            or counts["unsupported_findings"] != sum(x["unsupported_reason"] == "UNSUPPORTED_RULE" for x in unsupported)
            or counts["unscorable_findings"] != sum(x["unsupported_reason"] == "UNSCORABLE_FEATURE_EXTRACTION" for x in unsupported)
            or counts["failed_findings_total"] != sum(counts[x] for x in schema["counts"] if x != "failed_findings_total")):
        raise ValueError("JSON finding counts mismatch")
    if gate != "ERROR" and gate != gate_status(counts["failed_findings_total"]):
        raise ValueError("Gate status contradicts finding count")
    if gate != "ERROR":
        if any(not hash_value(document[key]) for key in ("run_id", "artifact_id", "context_id")):
            raise ValueError("Missing completed-run provenance")
        if document["input"]["artifact_sha256"] != document["artifact_id"] or not document["input"]["terraform_files"]:
            raise ValueError("Artifact provenance mismatch")
        context = document["business_context"]
        for key in ("environment", "asset_criticality", "data_sensitivity"):
            if context[key] not in domains[key]:
                raise ValueError("Invalid business context")
        profile = "|".join(context[key] for key in ("environment", "asset_criticality", "data_sensitivity"))
        if (context["context_profile_id"] != policy["business_context"]["context_profile_derivation"][profile]
                or document["context_id"] != context_id(context)):
            raise ValueError("Context provenance mismatch")
        for item in supported:
            if any(item["context_features"][key] != context[key] for key in ("environment", "asset_criticality", "data_sensitivity")):
                raise ValueError("Finding context differs from scan context")
        versions = document["tool_versions"]
        if (any(not isinstance(versions[key], str) or not versions[key] for key in schema["tool_versions"])
                or versions["checkov"] != "3.3.17"):
            raise ValueError("Missing or invalid tool provenance")
        model = document["model_provenance"]
        expected_model = {
            "deployment_model_id": "rf_severity_context_deployment_v1",
            "scientific_model_identity": "rf_severity_context_v1",
            "scientific_evaluation_source": "D-030 OOF Random Forest result",
            "deployment_model_sha256": ANCHORS[MODEL], "deployment_model_metadata_sha256": ANCHORS[METADATA],
            "deployment_model_scientifically_evaluated": False, "trust_status": "verified",
        }
        if any(model.get(key) != value for key, value in expected_model.items()) or model.get("deployment_model_scientifically_evaluated") is not False:
            raise ValueError("Model trust/scientific provenance mismatch")
        expected_run = run_id(document["artifact_id"], document["context_id"], versions["terraform"], versions["checkov"],
                              model["deployment_model_id"], model["deployment_model_sha256"], policy["policy_id"])
        if document["run_id"] != expected_run:
            raise ValueError("Run identity mismatch")
    try:
        timestamp = datetime.fromisoformat(document["created_at_utc"])
        if timestamp.utcoffset() is None or timestamp.utcoffset().total_seconds() != 0:
            raise ValueError("Timestamp must be UTC")
    except (TypeError, ValueError) as exc:
        raise ValueError("Invalid creation timestamp") from exc
    def walk(value):
        if isinstance(value, dict):
            if FORBIDDEN_FIELDS.intersection(value):
                raise ValueError("Research label exported as operational truth")
            for inner in value.values():
                walk(inner)
        elif isinstance(value, list):
            for inner in value:
                walk(inner)
    walk(document)
