"""Phase-8 operational Security Gate adapters; no scientific evaluation."""
