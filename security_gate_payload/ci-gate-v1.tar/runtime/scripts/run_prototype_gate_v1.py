"""Phase-8 operational Security Gate; no research evaluation or model fitting."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import numbers
import os
from pathlib import Path
import sys

import pandas as pd

from scripts.prototype_v1 import terraform_checkov as tools
from scripts.prototype_v1.feature_adapter import (
    FEATURES, SUPPORTED_RULES, FeatureExtractionError, extract_features_for_finding,
    load_applicability, load_severity,
)
from scripts.prototype_v1.normalization_identity import (
    CheckovParseError, ProvenanceError, SCHEMA_VERSION, artifact_id, context_id,
    parse_failed_findings, run_id, source_manifest, assert_source_manifest,
)
from scripts.prototype_v1.ranking_gate_schema import EXIT_CODES, gate_status, rank_supported, validate_output
from scripts.prototype_v1.trust import ANCHORS, METADATA, MODEL, REPO, ModelTrustError, load_accepted_model


class GateArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        raise ValueError(message)


def parser() -> argparse.ArgumentParser:
    p = GateArgumentParser(description="Phase-8 Terraform Security Gate")
    p.add_argument("--terraform", required=True, type=Path)
    p.add_argument("--environment", required=True, choices=("dev", "prod"))
    p.add_argument("--asset-criticality", required=True, choices=("low", "high"))
    p.add_argument("--data-sensitivity", required=True, choices=("low", "high"))
    p.add_argument("--output", required=True, type=Path)
    return p


def _base_document(root: Path, context: dict) -> dict:
    return {
        "schema_version": SCHEMA_VERSION, "run_id": None, "artifact_id": None,
        "context_id": None, "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "input": {"terraform_root": str(root), "terraform_files": [], "artifact_sha256": None},
        "business_context": {"environment": context.get("environment"),
                             "asset_criticality": context.get("asset_criticality"),
                             "data_sensitivity": context.get("data_sensitivity"),
                             "context_profile_id": None},
        "tool_versions": {"python": sys.version.split()[0], "terraform": None, "checkov": None},
        "model_provenance": {
            "deployment_model_id": "rf_severity_context_deployment_v1",
            "deployment_model_sha256": ANCHORS[MODEL],
            "deployment_model_metadata_sha256": ANCHORS[METADATA],
            "scientific_model_identity": "rf_severity_context_v1",
            "scientific_evaluation_source": "D-030 OOF Random Forest result",
            "deployment_model_scientifically_evaluated": False,
            "trust_status": "not_verified",
        },
        "execution_status": {key: "not_run" for key in (
            "terraform_init", "terraform_validate", "checkov_scan", "feature_extraction", "model_scoring")},
        "gate_status": "ERROR", "exit_code": 20,
        "counts": {"failed_findings_total": 0, "supported_findings": 0,
                   "unsupported_findings": 0, "unscorable_findings": 0},
        "ranked_supported_findings": [], "unsupported_findings": [],
        "warnings": [], "errors": [],
    }


def _output_path(path: Path) -> Path:
    if any(char in path.name for char in ("\n", "\r", "\\")) or path.name in {"", ".", ".."}:
        raise ValueError("Output filename cannot be represented safely in a checksum record")
    for destination in (path, checksum_path(path)):
        if destination.exists() or destination.is_symlink():
            raise FileExistsError(f"Output already exists: {destination}")
    parent = path.parent.absolute()
    if not parent.is_dir():
        raise ValueError("Output parent must be an existing non-symlink directory")
    cursor = parent
    while cursor != cursor.parent:
        if cursor.is_symlink():
            raise ValueError("Output parent path contains a symlink")
        cursor = cursor.parent
    return parent / path.name


def checksum_path(path: Path) -> Path:
    return Path(str(path) + ".sha256")


class OutputPackageError(OSError):
    """A partial pair may remain; never clean, overwrite, or retry automatically."""


def _write_bytes_at(parent_fd: int, name: str, content: bytes) -> None:
    fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=parent_fd)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
    except OSError as exc:
        raise OutputPackageError(f"Partial output file created; completion not confirmed: {name}; {exc}") from exc


def write_exclusive(path: Path, document: dict) -> None:
    if not path.is_absolute():
        raise ValueError("Output path must be absolute")
    _output_path(path)
    content = (json.dumps(document, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")
    record = f"{hashlib.sha256(content).hexdigest()}  {path.name}\n".encode("utf-8")
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    parent_fd = os.open("/", flags)
    wrote_json = False
    try:
        for component in path.parent.parts[1:]:
            next_fd = os.open(component, flags, dir_fd=parent_fd)
            os.close(parent_fd)
            parent_fd = next_fd
        # Both writes share the same opened destination directory, even if its
        # pathname is renamed while writing. Neither final file can be clobbered.
        _write_bytes_at(parent_fd, path.name, content)
        wrote_json = True
        _write_bytes_at(parent_fd, checksum_path(path).name, record)
        os.fsync(parent_fd)
    except OSError as exc:
        if wrote_json:
            raise OutputPackageError(f"Partial output package; JSON created, checksum not confirmed: {path}; {exc}") from exc
        raise
    finally:
        os.close(parent_fd)


def verify_output_package(path: Path) -> None:
    if path.is_symlink() or checksum_path(path).is_symlink():
        raise ValueError("Redirected output package")
    content = path.read_bytes()
    expected = f"{hashlib.sha256(content).hexdigest()}  {path.name}\n".encode("utf-8")
    if checksum_path(path).read_bytes() != expected:
        raise ValueError("Incomplete or checksum-invalid output package")


def _unsupported(finding: dict, reason: str, detail: str | None = None) -> dict:
    return {key: finding[key] for key in (
        "finding_id", "check_id", "check_name", "resource", "resource_type",
        "source_path", "line_start", "line_end",
    )} | {"unsupported_for_ml": True, "unsupported_reason": reason,
          "unsupported_detail": detail, "priority_score": None,
          "priority_rank_expected": None, "priority_tie_group_size": None}


def _supported(finding: dict, features: dict, severity: int, severity_version: str) -> dict:
    return {key: finding[key] for key in (
        "finding_id", "check_id", "check_name", "resource", "resource_type",
        "source_path", "line_start", "line_end",
    )} | {"severity_numeric": severity, "severity_mapping_version": severity_version,
          "context_features": features, "unsupported_for_ml": False,
          "priority_score": None, "priority_rank_expected": None,
          "priority_tie_group_size": None}


def _score(model, supported: list[dict], predictors: list[str], domains: dict) -> None:
    if not supported:
        return
    rows = []
    for finding in supported:
        row = {**finding["context_features"], "severity_numeric": finding["severity_numeric"]}
        if list(predictors) != ["environment", "asset_criticality", "data_sensitivity", *FEATURES, "severity_numeric"] or set(row) != set(predictors):
            raise ValueError("Prediction vector order mismatch")
        if any(row[field] not in domains[field] for field in domains):
            raise ValueError("Prediction vector category mismatch")
        if type(row["severity_numeric"]) is not int or row["severity_numeric"] not in {1, 2, 3, 4}:
            raise ValueError("Invalid severity predictor")
        rows.append(row)
    X = pd.DataFrame(rows, columns=predictors)
    if list(X.columns) != list(predictors):
        raise ValueError("Prediction matrix contract mismatch")
    values = model.predict(X)
    if len(values) != len(supported):
        raise ValueError("Prediction count mismatch")
    for finding, value in zip(supported, values):
        if isinstance(value, bool) or not isinstance(value, numbers.Real):
            raise ValueError("Invalid RF priority_score type")
        score = float(value)
        if not math.isfinite(score):
            raise ValueError("Nonfinite RF priority_score")
        finding["priority_score"] = score


def run_pipeline(root: Path, context: dict) -> tuple[dict, int]:
    """Execute one scan; errors are represented, never converted to PASS."""
    doc = _base_document(root, context)
    policy = None
    temporary = None
    try:
        if not root.is_dir():
            raise ProvenanceError("Terraform root is not a directory")
        if root.is_symlink():
            raise ProvenanceError("Terraform root is a symlink")
        root = root.resolve(strict=True)
        if any(context.get(k) not in values for k, values in {
            "environment": {"dev", "prod"}, "asset_criticality": {"low", "high"},
            "data_sensitivity": {"low", "high"},
        }.items()) or set(context) != {"environment", "asset_criticality", "data_sensitivity"}:
            raise ValueError("Invalid business context")
        intended = source_manifest(root)
        temporary, working_root = tools.isolated_copy(root)
        assert_source_manifest(working_root, intended)
        snapshot = source_manifest(working_root)
        artifact, tf_files = artifact_id(working_root)
        doc["artifact_id"] = artifact
        doc["input"].update(terraform_root=str(root), terraform_files=tf_files,
                            artifact_sha256=artifact)
        doc["context_id"] = context_id(context)
        doc["tool_versions"]["terraform"] = tools.terraform_version(working_root)
        doc["tool_versions"]["checkov"] = tools.checkov_version(REPO)
        assert_source_manifest(working_root, snapshot)
        statuses = tools.validate_terraform(working_root)
        doc["execution_status"].update(statuses)
        assert_source_manifest(working_root, snapshot)
        scan = tools.scan_checkov(working_root, REPO)
        assert_source_manifest(working_root, snapshot)
        raw = scan["stdout"]
        doc["execution_status"]["checkov_scan"] = {
            "status": "success", "returncode": scan["returncode"],
            "command": scan["command"], "stderr": scan["stderr"],
            "stdout_sha256": hashlib.sha256(raw.encode("utf-8")).hexdigest(),
        }
        findings, reported_version = parse_failed_findings(raw, working_root)
        doc["counts"]["failed_findings_total"] = len(findings)
        if reported_version and reported_version != doc["tool_versions"]["checkov"]:
            raise CheckovParseError("Checkov JSON version differs from executable")
        if doc["tool_versions"]["checkov"] != "3.3.17":
            raise CheckovParseError("Unsupported Checkov runtime version")
        model, metadata, policy = load_accepted_model()
        doc["model_provenance"]["trust_status"] = "verified"
        doc["run_id"] = run_id(artifact, doc["context_id"],
                               doc["tool_versions"]["terraform"],
                               doc["tool_versions"]["checkov"],
                               metadata["deployment_model_id"], ANCHORS[MODEL],
                               policy["policy_id"])
        profile_key = "|".join(context[key] for key in (
            "environment", "asset_criticality", "data_sensitivity"))
        doc["business_context"]["context_profile_id"] = policy["business_context"]["context_profile_derivation"][profile_key]
        if set(policy["supported_rules"]) != SUPPORTED_RULES:
            raise ModelTrustError("Frozen supported-rule allowlist mismatch")
        applicability = load_applicability()
        severity, severity_version = load_severity()
        domains = metadata["category_domains"]
        supported, unsupported = [], []
        for finding in findings:
            if finding["check_id"] not in SUPPORTED_RULES:
                unsupported.append(_unsupported(finding, "UNSUPPORTED_RULE"))
                continue
            try:
                technical, _ = extract_features_for_finding(
                    finding, working_root, applicability[finding["check_id"]], domains
                )
                features = {**context, **technical}
                if any(features[field] not in domains[field] for field in domains):
                    raise FeatureExtractionError("Frozen feature domain mismatch")
                supported.append(_supported(finding, features, severity[finding["check_id"]],
                                            severity_version))
            except FeatureExtractionError as exc:
                unsupported.append(_unsupported(finding, "UNSCORABLE_FEATURE_EXTRACTION", str(exc)))
        assert_source_manifest(working_root, snapshot)
        doc["execution_status"]["feature_extraction"] = "success"
        predictors = metadata["predictors"]
        _score(model, supported, predictors, domains)
        doc["execution_status"]["model_scoring"] = "success"
        doc["ranked_supported_findings"] = rank_supported(supported)
        doc["unsupported_findings"] = sorted(unsupported, key=lambda x: x["finding_id"])
        doc["counts"] = {
            "failed_findings_total": len(findings), "supported_findings": len(supported),
            "unsupported_findings": sum(x["unsupported_reason"] == "UNSUPPORTED_RULE" for x in unsupported),
            "unscorable_findings": sum(x["unsupported_reason"] == "UNSCORABLE_FEATURE_EXTRACTION" for x in unsupported),
        }
        doc["gate_status"] = gate_status(len(findings))
        doc["exit_code"] = EXIT_CODES[doc["gate_status"]]
        assert_source_manifest(working_root, snapshot)
        validate_output(doc, policy)
    except Exception as exc:
        if isinstance(exc, tools.ToolError):
            code = exc.code
            doc["execution_status"].update(exc.stages)
            if code == "TERRAFORM_INIT_ERROR":
                if not isinstance(doc["execution_status"]["terraform_init"], dict):
                    doc["execution_status"]["terraform_init"] = "error"
            elif code == "TERRAFORM_VALIDATE_ERROR":
                if not isinstance(doc["execution_status"]["terraform_validate"], dict):
                    doc["execution_status"]["terraform_validate"] = "error"
            elif code.startswith("CHECKOV"):
                doc["execution_status"]["checkov_scan"] = "error"
        elif isinstance(exc, ModelTrustError):
            code = "MODEL_TRUST_ERROR"
        elif isinstance(exc, CheckovParseError):
            code = "CHECKOV_JSON_PARSE_ERROR"
            doc["execution_status"]["checkov_scan"] = "error"
        elif isinstance(exc, ProvenanceError):
            code = "PROVENANCE_ERROR"
        else:
            code = "INTERNAL_ERROR"
        error = {"code": code, "message": str(exc)}
        if doc["counts"]["failed_findings_total"]:
            error["observed_failed_findings_total"] = doc["counts"]["failed_findings_total"]
        # In ERROR, counts describe retained validated rows, never an allegedly
        # complete scan. Preserve the observed scan count in the error evidence.
        doc["ranked_supported_findings"] = []
        doc["unsupported_findings"] = []
        doc["counts"] = dict.fromkeys(doc["counts"], 0)
        if isinstance(exc, tools.ToolError):
            error["tool_result"] = {
                key: value[:4000] if isinstance(value, str) else value
                for key, value in exc.details.items()
            }
        doc["errors"].append(error)
        doc["gate_status"] = "ERROR"
        doc["exit_code"] = 20
    finally:
        if temporary is not None:
            try:
                temporary.cleanup()
            except OSError as exc:
                doc["errors"].append({"code": "INTERNAL_ERROR", "message": f"Snapshot cleanup failed: {exc}"})
                doc["gate_status"], doc["exit_code"] = "ERROR", 20
    return doc, doc["exit_code"]


def main(argv=None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    try:
        args = parser().parse_args(arguments)
    except ValueError as exc:
        # Argparse may reject context before returning a Namespace. When one
        # unambiguous safe output path was supplied, record a structured ERROR
        # without inventing artifact/run identity or invoking any tool.
        if arguments.count("--output") == 1:
            index = arguments.index("--output")
            if index + 1 < len(arguments) and not arguments[index + 1].startswith("--"):
                try:
                    output = _output_path(Path(arguments[index + 1]))
                    document = _base_document(Path(arguments[arguments.index("--terraform") + 1])
                                              if "--terraform" in arguments and arguments.index("--terraform") + 1 < len(arguments)
                                              else Path(""), {})
                    document["errors"].append({"code": "INVALID_CONTEXT", "message": str(exc)})
                    write_exclusive(output, document)
                except (OSError, ValueError):
                    pass
        print(f"INVALID_CONTEXT: {exc}", file=sys.stderr)
        return 20
    try:
        output = _output_path(args.output)
    except (OSError, ValueError) as exc:
        print(f"OUTPUT_ERROR: {exc}", file=sys.stderr)
        return 20
    context = {"environment": args.environment, "asset_criticality": args.asset_criticality,
               "data_sensitivity": args.data_sensitivity}
    document, exit_code = run_pipeline(args.terraform, context)
    try:
        write_exclusive(output, document)
    except (OSError, ValueError) as exc:
        print(f"OUTPUT_ERROR: {exc}", file=sys.stderr)
        return 20
    print(f"{document['gate_status']}: {output}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
